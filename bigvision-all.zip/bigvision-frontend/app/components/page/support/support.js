App.controller('WebStructureController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, RoleAccessService) {
    $scope.loading = true;
    ngDialog.closeAll();
    $scope.projectStatus = 'faqs';
    
    
    
////////////////////=============================Get  My Quotes=============================//////////////////////
    
    $scope.changeProjectStatus = function (status) {
        if (status == 'faqs') {
            $scope.projectStatus = "faqs";
        }
        else if (status == 'contact') {
            $scope.projectStatus = "contact";
        }
    }
    
  
    
    
////////////////////=============================faqsList=============================//////////////////////
$scope.faqsList = {};
$scope.faqs = function () {
    ApiService.apiCall('/FAQs/getFAQs', 'GET', 0).success(function (response) {
        $scope.faqsList = response.data;
        //console.log("faqsList", $scope.faqsList);
    }).error(function (response) {
        //console.log("faqsList", response);
    })
}
$scope.faqs();
    

    
    
    
////////////////////=============================faqsList=============================//////////////////////
$scope.getContact = {};
$scope.getContactUs = function () {
    ApiService.apiCall('/admin/cms/getContactUs', 'GET', 0)
    
    .success(function (response) {
     
        //console.log("getContact",response.data[0]);
        
       $scope.getContact = response.data[0];
        
        
    })
    
    .error(function (response) {
        //console.log("faqsList", response);
    })
}
$scope.getContactUs();  
    
    
    
    
    
    
    
    
    
    
    
})