/**
 * Created by admin-in on 21/4/17.
 */
App.controller('videographerDashboard-ctrl', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService, $log, $sce, jwplayerService) {
    "use strict";
    $scope.loading = true;
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.page = 10;
    $scope.uid = $cookieStore.get('profileDetails').id;
    $scope.videographerId = {};
    //  //console.log($cookieStore.get('obj').accessToken);
    //  //console.log($cookieStore.get('obj').isDetailsFilled);
    //    
    //



    $scope.getReviews = function(skip){

        ApiService.apiCall('/review/getVideographerReviews?videographerId='+$scope.uid+'&limit='+10+'&skip='+skip, 'GET', 2)
            .success(function (response) {
               $scope.count = response.data.count;
                $scope.alldata = response.data.userData;
            }).error(function (response) {
            //console.log(response);

            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            setTimeout(function () {
                ngDialog.close();
            }, 1000);
        })
    }
    $scope.getReviews(0);
    //////////////////////=============================Videographer Details=============================//////////////////////   
    $scope.getVideographerDetails = function () {
        $http({
            url: MY_CONSTANT.url + '/user/getDetails'
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            $scope.Videographer = response.data.user;
            $scope.videographerId = response.data.user._id;


            //console.log("$scope.videographerId", $scope.videographerId);
            
            
            $scope.videoCategory = response.data.user.videographer.categoryNames;
             $scope.videoskill = response.data.user.videographer.skills;
            
            
            
            
            var maintags = response.data.user.videographer.skills;
            $scope.getTagsList =  maintags.substr(0,maintags.length);
                            
            $scope.getTags = $scope.getTagsList.split(',');
            console.log("$scope.getTagsList", $scope.getTags);
         
            
            
            if ($scope.Videographer.profilePictureURL == "undefined" ||  $scope.Videographer.profilePictureURL == " ") {
                $scope.Videographer.profilePictureURL = 'app/img/no-profile-image.png';
            }
            
          
               $scope.getIt();
            
            
        })
            
            
            
            
            .error(function (response) {
            //console.log("errorr", response);

            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
        ngDialog.closeAll();
    }
    $scope.getVideographerDetails();
    //////////////////////=============================LOGOUT=============================//////////////////////
    $scope.logout = function () {
        $http({
            url: MY_CONSTANT.url + '/user/logout'
            , method: 'PUT'
            , headers: {
                authorization: "bearer " + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            //console.log(localStorage.getItem("CurrentAccess"));
            if (response.statusCode == 200) {
                $cookieStore.remove('obj');
                /* $cookieStore.remove('role');*/
                $state.go('page.mainLanding')
            }
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        });
    }
    $rootScope.$on('picUpload', function () {
            $scope.name = $cookieStore.get('obj').name;
            if ($cookieStore.get('obj').profilePictureURL && $cookieStore.get('obj').profilePictureURL != 'undefined') {
                $scope.profilePictureURL = $cookieStore.get('obj').profilePictureURL;
            }
            else {
                $scope.profilePictureURL = 'app/img/no-profile-image.png';
            }
        })
        //-------------------------------------Get  Video--------------------------------------- 
    $scope.videoProject = 0;

    

        $scope.getIt = function () {
            //console.log("inside getvideo");
                  $http({
            url: MY_CONSTANT.url + '/user/getProjectFiles?isPortfolio=' +true+'&videographerId='+$scope.videographerId
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
            , transformRequest: angular.identity
        })
                
                
                
                
                
                .success(function (response) {
                //console.log("getMedia", response.data);

                $scope.loading = false;
                $scope.videoProject = response.data;
                if ($scope.videoProject.count == 0) {
                    $scope.noContent = true;
                }
                $scope.getvideoCount = response.data.count;
                if ($scope.getvideoCount == 0) {
                    $scope.noContent = true;
                    $scope.loading = false;
                }
                //console.log($scope.getvideoCount);
                if (response.data.count != 0) {
                    $scope.mediaurl = response.data.files[0].fileURL;
                    $scope.posterURL = response.data.files[0].posterURL;
                    $scope.filelist = response.data.files
                }
                //console.log($scope.mediaurl);
                $timeout(function () {
                    $scope.name = 'JWPlayer Player ';
                    $scope.options = {
                        type: 'mp4'
                        , image: $scope.posterURL
                        , skin: {
                            active: '#bc2131'
                            , background: '#000000'
                            , inactive: '#fff'
                        , }
                    };
                    $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
                    $scope.$on('ng-jwplayer-ready', function (event, args) {
                        $log.info('Player ' + args.playerId + ' ready. Playing video');
                        var player = jwplayerService.myPlayer[args.playerId];
                        player.getFullscreen(true);
                    });
                    $timeout(function () {
                        $scope.loading = false;
                    }, 3000);
                }, 500);
            }).error(function (response) {
                $scope.loading = false;
                //console.log("error getMedia");
                //console.log(response);
            })
        }
        //-------------------------------------Play Video--------------------------------------- 
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image: $scope.posterURL
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
    }
    $scope.showVideoPlayerPopup = function (video_path, thumb_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        $scope.$on('ngDialog.opened', function (e, $dialog) {
            $scope.mediaurl = video_path;
            $scope.posterURL = thumb_path;
            $scope.playVideo();
            //console.log($scope.mediaurl);
            //            //console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
    }
})