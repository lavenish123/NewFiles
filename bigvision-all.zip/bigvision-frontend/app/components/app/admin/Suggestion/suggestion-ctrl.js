/**
 * Created by admin-in on 6/7/17.
 */


App.controller('suggestionController', function ($scope,$state,ngDialog, $http,ApiService, $cookies, $cookieStore, MY_CONSTANT, $timeout) {

    'use strict';

    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = "/^[a-zA-Z\s]*$/";
    /*/^[a-zA-Z ]{2,30}$/;*/
    $scope.loading = false;
    $scope.cmsRole = 0;
    $scope.page = 10;
    $scope.sno = 0;
    $scope.tableCustomer = false;
    $scope.tableVideographer = false;
    $('#successMsg').hide();
    $('#errorMsg').hide();

    $scope.message = '';

    $scope.getSuggestion = function(skip1)
    {
        ApiService.apiCall('/admin/getSuggestion?limit='+10+'&skip='+skip1, 'GET', 2)
            .success(function (data) {
                $scope.loading = false;
                if (data.statusCode == 200) {

                    $scope.suggestion = data.data.userData;
                    $scope.count = data.data.count;

                }
            })
            .error(function (response) {
                $('#errorMsg').slideDown('slow');
                $scope.errorMsgR = 'Something Went Wrong';
                $timeout(function () {
                    $('#successMsg').slideUp('slow');
                    $scope.successMsg = '';
                    ngDialog.close();
                    $state.reload();
                }, 3000);
            })
    }
    $scope.getSuggestion(0);





    $scope.deleteSug = function (id){
        var fd = new FormData();
        fd.append('suggestionId',id);
        ApiService.apiCall('/admin/deleteSuggestion', 'PUT', 3,fd)
            .success(function (data) {
                $scope.loading = false;
                if (data.statusCode == 200) {

                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);

                }
            })
            .error(function (response) {
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
            })
    }









    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }


});