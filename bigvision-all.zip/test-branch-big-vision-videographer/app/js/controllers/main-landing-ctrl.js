App.controller('mainLandingController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location) {
    "use strict";
    // =================Function for Searching the videographer=====================
    $scope.searchVideoGrapher = function () {
            var location = document.getElementById('address').value;
            //var city = location.substr(0,location.indexOf(","));
            var city;
            if (location.indexOf(",") > 1) {
                city = location.substr(0, location.indexOf(","));
            }
            else {
                city = location;
            }
            $state.go('page.search', {
                "city": city
                , "name": $scope.registration.name
            });
        }
        //=========================Go  Top==========================    
    $scope.goTop = function () {
            $('html, body').animate({
                scrollTop: 0
            }, 'slow');
        }
        //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;

    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')), {
            types: ['(cities)']
        });
        autocomplete.addListener('place_changed', fillInAddress);
    }

    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        $timeout(function () {
            $scope.map = {
                zoom: 14
                , center: new google.maps.LatLng(30.718868, 76.810499)
                , pan: true
            };
            $scope.mapContainer = new google.maps.Map(document.getElementById('map-container'), $scope.map);
            $scope.deliveryAddressMarker(place);
        }, 1000)
    }
    initAutocomplete();
    $scope.closeAddressDialog = function () {
        $('#assign-address').modal('hide');
    };
    //=========================add marker on delivery address==========================
    $scope.deliveryAddressMarker = function (address) {
        $scope.registration.address = $('#address').val();
        $scope.showAddress = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.map = {
                    zoom: 14
                    , center: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())
                    , pan: true
                };
                var panPoint = new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng());
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();
                $scope.mapContainer.panTo(panPoint);
                var icon = 'app/img/redMarker.png';
                if (markerArr.length) {
                    for (i = 0; i < markerArr.length; i++) markerArr[i].setMap(null);
                    markerArr.pop();
                }
                var marker = new google.maps.Marker({
                    map: $scope.mapContainer
                    , icon: icon
                    , position: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())
                    , draggable: true
                });
                google.maps.event.addListener(marker, 'drag', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
                google.maps.event.addListener(marker, 'dragend', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
            }
            else {
                $scope.displaymsg = 'Delivery address is not valid';
                ngDialog.open({
                    template: 'display_msg_modalDialog1'
                    , className: 'ngdialog-theme-default'
                    , showClose: false
                    , scope: $scope
                });
            }
        });
    };
    //=========================place marker on given lat lng==========================
    $scope.placeMarker = function (lat, long) {
        var icon = 'app/img/redMarker.png';
        var marker = new google.maps.Marker({
            map: $scope.mapContainer
            , icon: icon
            , position: new google.maps.LatLng(lat, long)
            , draggable: true
        });
        if (markerArr.length) {
            for (var i = 0; i < markerArr.length; i++) markerArr[i].setMap(null);
            markerArr.pop();
        }
        markerArr.push(marker);
        google.maps.event.addListener(marker, 'drag', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
        google.maps.event.addListener(marker, 'dragend', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
    };
    //=========================reverse geocode to get address==========================
    $scope.reverseGeocode = function (latlong) {
        (new google.maps.Geocoder()).geocode({
            'latLng': latlong
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#address').val(results[0].formatted_address);
                    $scope.registration.address = results[0].formatted_address;
                    $scope.showAddress = results[0].formatted_address;
                    $scope.$apply();
                }
            }
        });
    };
});