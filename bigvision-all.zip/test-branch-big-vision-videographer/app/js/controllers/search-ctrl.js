/**
 * Created by admin-in on 27/4/17.
 */
App.controller('searchController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.showafterLogin = false;
    if ($cookieStore.get('searchdata')) {
        $scope.ff = 2;
        var location = $cookieStore.get('searchdata').address;
        var city;
        if (location.indexOf(",") > 1) {
            city = location.substr(0, location.indexOf(","));
        }
        else {
            city = location;
        }
        $scope.data = {
            "address": $cookieStore.get('searchdata').address
            , "looking": $cookieStore.get('searchdata').looking
        };
        var obj = {
            "address": city
            , "looking": $cookieStore.get('searchdata').looking
        }
    }
    else {
        $scope.data = {
            "address": ''
            , "looking": ''
        };
        var obj = {
            "address": $stateParams.city
            , "looking": $stateParams.looking
        }
    }
    if ($cookieStore.get('obj')) {
        $scope.showafterLogin = true;
    }
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    ///////////////////////////=======================================SEARCH VIDEOGRAPHER=======================/////////////////////////////
    $scope.getVideographer = function (reg, f) {
        var location = document.getElementById('address').value;
        var city;
        if (location.indexOf(",") > 1) {
            city = location.substr(0, location.indexOf(","));
        }
        else {
            city = location;
        }
        var fd = new FormData();
        if (f == 1) {
            if (city != '') {
                fd.append('city', city);
            }
            if (reg.address != '' && reg.looking != '') {
                $scope.flag = 1;
            }
            else if (reg.address == '' && reg.looking != '') {
                $scope.flag = 2;
            }
            else if (reg.address != '' && reg.looking == '') {
                $scope.flag = 3;
            }
        }
        else if ($scope.ff == 2) {
            if (reg.address != '') {
                fd.append('city', reg.address);
            }
            if ((reg.address) && (reg.looking)) {
                $scope.flag = 1;
            }
            else if (reg.address == '' && reg.looking != '') {
                $scope.flag = 2;
            }
            else if (reg.address != '' && reg.looking == '') {
                $scope.flag = 3;
            }
        }
        else {
            if (reg.address != '') {
                fd.append('city', reg.address);
            }
            if ((reg.address != undefined) && (reg.looking != undefined)) {
                $scope.flag = 1;
            }
            else if (reg.address == undefined && reg.looking != undefined) {
                $scope.flag = 2;
            }
            else if (reg.address != undefined && reg.looking == undefined) {
                $scope.flag = 3;
            }
        }
        if (reg.looking == '' || reg.looking == undefined) {}
        else {
            fd.append('videographerName', reg.looking);
        }
        $http({
            method: 'PUT'
            , url: MY_CONSTANT.url + '/user/videographerSearch'
            , headers: {
                'Content-type': undefined
            }
            , data: fd
        }).success(function (response) {
            if ($scope.flag == 3) {
                $scope.list = response.data.cityWiseList;
                $scope.count = response.data.cityWiseListCount;
            }
            else if ($scope.flag == 2) {
                $scope.list = response.data.nameWiseList;
                $scope.count = response.data.nameWiseListCount;
            }
            else if ($scope.flag == 1) {
                $scope.list = response.data.nameAndCityWiseList;
                $scope.count = response.data.nameAndCityWiseListCount;
            }
            else {
                $scope.list = [];
                $scope.count = "No";
            }
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.close();
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            
             if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.getVideographer(obj);
    $scope.loginpopup = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'customer-login'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }
    $scope.loginAlert = function (data) {
        $scope.searchDetailId = data;
        $scope.searchId = $scope.searchDetailId._id;
        $scope.searchUniqueId = $scope.searchDetailId.videographer.uniqueId;
        $scope.alertMsg = "Please Login to view the details of videographer";
        ngDialog.open({
            template: 'login-alert'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }
    $scope.okClick = function () {
            ngDialog.close();
        }
        //////////////////////=============================LOGIN FUNCTION=============================//////////////////////
    $scope.searchLogin = function (data) {
        var fd = new FormData();
        fd.append('email', data.email);
        fd.append('password', data.password);
        fd.append('deviceType', 'WEB');
        fd.append('role', 'customer');
        $scope.loading = true;
        $http({
            url: MY_CONSTANT.url + '/user/login'
            , method: 'POST'
            , headers: {
                'Content-type': undefined
            }
            , data: fd
            , transformRequest: angular.identity
        }).success(function (response) {
            $scope.loading = false;
            if (response.statusCode == 200) {
                $cookieStore.put('pic', response.data.user.profilePictureURL);
                $rootScope.$broadcast('picupload');
                var obj = {
                    'accessToken': response.data.token
                    , 'userRole': response.data.user.role
                    , 'status': response.data.user.isActive
                    , 'name': response.data.user.name
                };
                $cookieStore.put('obj', obj);
                if (response.data.user.isEmailVerified == true) {
                    if (response.data.user.role == 'customer') {
                        $scope.closeDialog();
                        $state.go('app.searchDetails', {
                            'id': $scope.searchId
                            , 'uniqueid': $scope.searchUniqueId
                        });
                    }
                    else {
                        if (response.data.user.isDetailsFilled == false) {
                            $scope.closeDialog();
                            $state.go('app.upload');
                        }
                        else if (response.data.user.isDetailsFilled == true) {
                            $scope.closeDialog();
                            $state.go('app.NewsearchDetails');
                        }
                    }
                }
                else {
                    $scope.otpAfterLogin();
                }
            }
        }).error(function (response) {
            $scope.loading = false;
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            
             if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
});