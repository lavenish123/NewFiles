/**
 * Created by admin-in on 27/4/17.
 */
App.controller('searchDetails', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.videographerId = $stateParams.id
    $scope.uniqueid = $stateParams.uniqueid
        ///////////////////////////=======================================Details VIDEOGRAPHER=======================/////////////////////////////
    $scope.getDetails = function () {
        var fd = new FormData();
        fd.append('uniqueId', $scope.uniqueid);
        $http({
            method: 'PUT'
            , url: MY_CONSTANT.url + '/user/videographerSearch'
            , headers: {
                'Content-type': undefined
            }
            , data: fd
        }).success(function (response) {
            $scope.data = response.data.uniqueIdSearch[0];
        }).error(function (response) {
            $scope.message = response.message;
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.getDetails();
    //////////////////////=============================Quote POPUP=============================//////////////////////
    $scope.quotePopupFun = function () {
        $scope.existProject = {};
        $http({
            url: MY_CONSTANT.url + '/project/getUnassignedProjects'
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            $scope.list1 = response.data.projects;
        }).error(function (response) {
            console.log("errorr", response);
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
        ngDialog.open({
            template: 'quote-Popup'
            , className: 'ngdialog-theme-default commandialog getquote'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }
    $scope.postJobFun = function (valid) {
            if (valid) {
                if ($scope.existProject.mode == "MANUALLY") {
                    $state.go("app.postjob", {
                        'videographerId': $scope.videographerId
                        , 'projectId': $scope.existProject.project
                    });
                }
                else {
                    $state.go("app.postjob", {
                        'videographerId': $scope.videographerId
                    });
                }
            }
        }
        //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
})