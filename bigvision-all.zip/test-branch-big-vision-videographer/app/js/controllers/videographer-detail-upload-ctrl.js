/**
 * Created by admin-in on 21/4/17.
 */
App.controller('videographerDetailUpload', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, countryCode) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.numberRegex = /^[0-9]+$/;
    $scope.distanceRegex = /^[1-9]\d*(\.\d+)?$/;
    $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.alphaRegex = /^[a-zA-z]{1,}$/;
    $scope.alphaSpaceRegex = /^[a-zA-z\s]{1,}$/;

    /*$scope.user={'countryCode':+1};*/
    // $scope.user = {'countryCode' : {"name": "United States", "dial_code": "+1", "code": "US"}};

    $scope.phnRegex = /[^0][0-9]{5,}$/;
    // $scope.dropDown = [{ "name": "Israel", "dial_code": "+972", "code": "IL" }, { "name": "Afghanistan", "dial_code": "+93", "code": "AF" }, { "name": "Albania", "dial_code": "+355", "code": "AL" }, { "name": "Algeria", "dial_code": "+213", "code": "DZ" }, { "name": "AmericanSamoa", "dial_code": "+1", "code": "AS" }, { "name": "Andorra", "dial_code": "+376", "code": "AD" }, { "name": "Angola", "dial_code": "+244", "code": "AO" }, { "name": "Anguilla", "dial_code": "+1", "code": "AI" }, { "name": "Antigua and Barbuda", "dial_code": "+1268", "code": "AG" }, { "name": "Argentina", "dial_code": "+54", "code": "AR" }, { "name": "Armenia", "dial_code": "+374", "code": "AM" }, { "name": "Aruba", "dial_code": "+297", "code": "AW" }, { "name": "Australia", "dial_code": "+61", "code": "AU" }, { "name": "Austria", "dial_code": "+43", "code": "AT" }, { "name": "Azerbaijan", "dial_code": "+994", "code": "AZ" }, { "name": "Bahamas", "dial_code": "+1", "code": "BS" }, { "name": "Bahrain", "dial_code": "+973", "code": "BH" }, { "name": "Bangladesh", "dial_code": "+880", "code": "BD" }, { "name": "Barbados", "dial_code": "+1", "code": "BB" }, { "name": "Belarus", "dial_code": "+375", "code": "BY" }, { "name": "Belgium", "dial_code": "+32", "code": "BE" }, { "name": "Belize", "dial_code": "+501", "code": "BZ" }, { "name": "Benin", "dial_code": "+229", "code": "BJ" }, { "name": "Bermuda", "dial_code": "+1", "code": "BM" }, { "name": "Bhutan", "dial_code": "+975", "code": "BT" }, { "name": "Bosnia and Herzegovina", "dial_code": "+387", "code": "BA" }, { "name": "Botswana", "dial_code": "+267", "code": "BW" }, { "name": "Brazil", "dial_code": "+55", "code": "BR" }, { "name": "British Indian Ocean Territory", "dial_code": "+246", "code": "IO" }, { "name": "Bulgaria", "dial_code": "+359", "code": "BG" }, { "name": "Burkina Faso", "dial_code": "+226", "code": "BF" }, { "name": "Burundi", "dial_code": "+257", "code": "BI" }, { "name": "Cambodia", "dial_code": "+855", "code": "KH" }, { "name": "Cameroon", "dial_code": "+237", "code": "CM" }, { "name": "Canada", "dial_code": "+1", "code": "CA" }, { "name": "Cape Verde", "dial_code": "+238", "code": "CV" }, { "name": "Cayman Islands", "dial_code": "+ 345", "code": "KY" }, { "name": "Central African Republic", "dial_code": "+236", "code": "CF" }, { "name": "Chad", "dial_code": "+235", "code": "TD" }, { "name": "Chile", "dial_code": "+56", "code": "CL" }, { "name": "China", "dial_code": "+86", "code": "CN" }, { "name": "Christmas Island", "dial_code": "+61", "code": "CX" }, { "name": "Colombia", "dial_code": "+57", "code": "CO" }, { "name": "Comoros", "dial_code": "+269", "code": "KM" }, { "name": "Congo", "dial_code": "+242", "code": "CG" }, { "name": "Cook Islands", "dial_code": "+682", "code": "CK" }, { "name": "Costa Rica", "dial_code": "+506", "code": "CR" }, { "name": "Croatia", "dial_code": "+385", "code": "HR" }, { "name": "Cuba", "dial_code": "+53", "code": "CU" }, { "name": "Cyprus", "dial_code": "+537", "code": "CY" }, { "name": "Czech Republic", "dial_code": "+420", "code": "CZ" }, { "name": "Denmark", "dial_code": "+45", "code": "DK" }, { "name": "Djibouti", "dial_code": "+253", "code": "DJ" }, { "name": "Dominica", "dial_code": "+1", "code": "DM" }, { "name": "Dominican Republic", "dial_code": "+1", "code": "DO" }, { "name": "Ecuador", "dial_code": "+593", "code": "EC" }, { "name": "Egypt", "dial_code": "+20", "code": "EG" }, { "name": "El Salvador", "dial_code": "+503", "code": "SV" }, { "name": "Equatorial Guinea", "dial_code": "+240", "code": "GQ" }, { "name": "Eritrea", "dial_code": "+291", "code": "ER" }, { "name": "Estonia", "dial_code": "+372", "code": "EE" }, { "name": "Ethiopia", "dial_code": "+251", "code": "ET" }, { "name": "Faroe Islands", "dial_code": "+298", "code": "FO" }, { "name": "Fiji", "dial_code": "+679", "code": "FJ" }, { "name": "Finland", "dial_code": "+358", "code": "FI" }, { "name": "France", "dial_code": "+33", "code": "FR" }, { "name": "French Guiana", "dial_code": "+594", "code": "GF" }, { "name": "French Polynesia", "dial_code": "+689", "code": "PF" }, { "name": "United States", "dial_code": "+1", "code": "US" }, { "name": "Gabon", "dial_code": "+241", "code": "GA" }, { "name": "Gambia", "dial_code": "+220", "code": "GM" }, { "name": "Georgia", "dial_code": "+995", "code": "GE" }, { "name": "Germany", "dial_code": "+49", "code": "DE" }, { "name": "Ghana", "dial_code": "+233", "code": "GH" }, { "name": "Gibraltar", "dial_code": "+350", "code": "GI" }, { "name": "Greece", "dial_code": "+30", "code": "GR" }, { "name": "Greenland", "dial_code": "+299", "code": "GL" }, { "name": "Grenada", "dial_code": "+1", "code": "GD" }, { "name": "Guadeloupe", "dial_code": "+590", "code": "GP" }, { "name": "Guam", "dial_code": "+1", "code": "GU" }, { "name": "Guatemala", "dial_code": "+502", "code": "GT" }, { "name": "Guinea", "dial_code": "+224", "code": "GN" }, { "name": "Guinea-Bissau", "dial_code": "+245", "code": "GW" }, { "name": "Guyana", "dial_code": "+595", "code": "GY" }, { "name": "Haiti", "dial_code": "+509", "code": "HT" }, { "name": "Honduras", "dial_code": "+504", "code": "HN" }, { "name": "Hungary", "dial_code": "+36", "code": "HU" }, { "name": "Iceland", "dial_code": "+354", "code": "IS" }, { "name": "India", "dial_code": "+91", "code": "IN" }, { "name": "Indonesia", "dial_code": "+62", "code": "ID" }, { "name": "Iraq", "dial_code": "+964", "code": "IQ" }, { "name": "Ireland", "dial_code": "+353", "code": "IE" }, { "name": "Israel", "dial_code": "+972", "code": "IL" }, { "name": "Italy", "dial_code": "+39", "code": "IT" }, { "name": "Jamaica", "dial_code": "+1", "code": "JM" }, { "name": "Japan", "dial_code": "+81", "code": "JP" }, { "name": "Jordan", "dial_code": "+962", "code": "JO" }, { "name": "Kazakhstan", "dial_code": "+7", "code": "KZ" }, { "name": "Kenya", "dial_code": "+254", "code": "KE" }, { "name": "Kiribati", "dial_code": "+686", "code": "KI" }, { "name": "Kuwait", "dial_code": "+965", "code": "KW" }, { "name": "Kyrgyzstan", "dial_code": "+996", "code": "KG" }, { "name": "Latvia", "dial_code": "+371", "code": "LV" }, { "name": "Lebanon", "dial_code": "+961", "code": "LB" }, { "name": "Lesotho", "dial_code": "+266", "code": "LS" }, { "name": "Liberia", "dial_code": "+231", "code": "LR" }, { "name": "Liechtenstein", "dial_code": "+423", "code": "LI" }, { "name": "Lithuania", "dial_code": "+370", "code": "LT" }, { "name": "Luxembourg", "dial_code": "+352", "code": "LU" }, { "name": "Madagascar", "dial_code": "+261", "code": "MG" }, { "name": "Malawi", "dial_code": "+265", "code": "MW" }, { "name": "Malaysia", "dial_code": "+60", "code": "MY" }, { "name": "Maldives", "dial_code": "+960", "code": "MV" }, { "name": "Mali", "dial_code": "+223", "code": "ML" }, { "name": "Malta", "dial_code": "+356", "code": "MT" }, { "name": "Marshall Islands", "dial_code": "+692", "code": "MH" }, { "name": "Martinique", "dial_code": "+596", "code": "MQ" }, { "name": "Mauritania", "dial_code": "+222", "code": "MR" }, { "name": "Mauritius", "dial_code": "+230", "code": "MU" }, { "name": "Mayotte", "dial_code": "+262", "code": "YT" }, { "name": "Mexico", "dial_code": "+52", "code": "MX" }, { "name": "Monaco", "dial_code": "+377", "code": "MC" }, { "name": "Mongolia", "dial_code": "+976", "code": "MN" }, { "name": "Montenegro", "dial_code": "+382", "code": "ME" }, { "name": "Montserrat", "dial_code": "+1664", "code": "MS" }, { "name": "Morocco", "dial_code": "+212", "code": "MA" }, { "name": "Myanmar", "dial_code": "+95", "code": "MM" }, { "name": "Namibia", "dial_code": "+264", "code": "NA" }, { "name": "Nauru", "dial_code": "+674", "code": "NR" }, { "name": "Nepal", "dial_code": "+977", "code": "NP" }, { "name": "Netherlands", "dial_code": "+31", "code": "NL" }, { "name": "Netherlands Antilles", "dial_code": "+599", "code": "AN" }, { "name": "New Caledonia", "dial_code": "+687", "code": "NC" }, { "name": "New Zealand", "dial_code": "+64", "code": "NZ" }, { "name": "Nicaragua", "dial_code": "+505", "code": "NI" }, { "name": "Niger", "dial_code": "+227", "code": "NE" }, { "name": "Nigeria", "dial_code": "+234", "code": "NG" }, { "name": "Niue", "dial_code": "+683", "code": "NU" }, { "name": "Norfolk Island", "dial_code": "+672", "code": "NF" }, { "name": "Northern Mariana Islands", "dial_code": "+1", "code": "MP" }, { "name": "Norway", "dial_code": "+47", "code": "NO" }, { "name": "Oman", "dial_code": "+968", "code": "OM" }, { "name": "Pakistan", "dial_code": "+92", "code": "PK" }, { "name": "Palau", "dial_code": "+680", "code": "PW" }, { "name": "Panama", "dial_code": "+507", "code": "PA" }, { "name": "Papua New Guinea", "dial_code": "+675", "code": "PG" }, { "name": "Paraguay", "dial_code": "+595", "code": "PY" }, { "name": "Peru", "dial_code": "+51", "code": "PE" }, { "name": "Philippines", "dial_code": "+63", "code": "PH" }, { "name": "Poland", "dial_code": "+48", "code": "PL" }, { "name": "Portugal", "dial_code": "+351", "code": "PT" }, { "name": "Puerto Rico", "dial_code": "+1", "code": "PR" }, { "name": "Qatar", "dial_code": "+974", "code": "QA" }, { "name": "Romania", "dial_code": "+40", "code": "RO" }, { "name": "Rwanda", "dial_code": "+250", "code": "RW" }, { "name": "Samoa", "dial_code": "+685", "code": "WS" }, { "name": "San Marino", "dial_code": "+378", "code": "SM" }, { "name": "Saudi Arabia", "dial_code": "+966", "code": "SA" }, { "name": "Senegal", "dial_code": "+221", "code": "SN" }, { "name": "Serbia", "dial_code": "+381", "code": "RS" }, { "name": "Seychelles", "dial_code": "+248", "code": "SC" }, { "name": "Sierra Leone", "dial_code": "+232", "code": "SL" }, { "name": "Singapore", "dial_code": "+65", "code": "SG" }, { "name": "Slovakia", "dial_code": "+421", "code": "SK" }, { "name": "Slovenia", "dial_code": "+386", "code": "SI" }, { "name": "Solomon Islands", "dial_code": "+677", "code": "SB" }, { "name": "South Africa", "dial_code": "+27", "code": "ZA" }, { "name": "South Georgia and the South Sandwich Islands", "dial_code": "+500", "code": "GS" }, { "name": "Spain", "dial_code": "+34", "code": "ES" }, { "name": "Sri Lanka", "dial_code": "+94", "code": "LK" }, { "name": "Sudan", "dial_code": "+249", "code": "SD" }, { "name": "Suriname", "dial_code": "+597", "code": "SR" }, { "name": "Swaziland", "dial_code": "+268", "code": "SZ" }, { "name": "Sweden", "dial_code": "+46", "code": "SE" }, { "name": "Switzerland", "dial_code": "+41", "code": "CH" }, { "name": "Tajikistan", "dial_code": "+992", "code": "TJ" }, { "name": "Thailand", "dial_code": "+66", "code": "TH" }, { "name": "Togo", "dial_code": "+228", "code": "TG" }, { "name": "Tokelau", "dial_code": "+690", "code": "TK" }, { "name": "Tonga", "dial_code": "+676", "code": "TO" }, { "name": "Trinidad and Tobago", "dial_code": "+1", "code": "TT" }, { "name": "Tunisia", "dial_code": "+216", "code": "TN" }, { "name": "Turkey", "dial_code": "+90", "code": "TR" }, { "name": "Turkmenistan", "dial_code": "+993", "code": "TM" }, { "name": "Turks and Caicos Islands", "dial_code": "+1", "code": "TC" }, { "name": "Tuvalu", "dial_code": "+688", "code": "TV" }, { "name": "Uganda", "dial_code": "+256", "code": "UG" }, { "name": "Ukraine", "dial_code": "+380", "code": "UA" }, { "name": "United Arab Emirates", "dial_code": "+971", "code": "AE" }, { "name": "United Kingdom", "dial_code": "+44", "code": "GB" }, { "name": "Uruguay", "dial_code": "+598", "code": "UY" }, { "name": "Uzbekistan", "dial_code": "+998", "code": "UZ" }, { "name": "Vanuatu", "dial_code": "+678", "code": "VU" }, { "name": "Wallis and Futuna", "dial_code": "+681", "code": "WF" }, { "name": "Yemen", "dial_code": "+967", "code": "YE" }, { "name": "Zambia", "dial_code": "+260", "code": "ZM" }, { "name": "Zimbabwe", "dial_code": "+263", "code": "ZW" }, { "name": "land Islands", "dial_code": "", "code": "AX" }, { "name": "Antarctica", "dial_code": null, "code": "AQ" }, { "name": "Bolivia, Plurinational State of", "dial_code": "+591", "code": "BO" }, { "name": "Brunei Darussalam", "dial_code": "+673", "code": "BN" }, { "name": "Cocos (Keeling) Islands", "dial_code": "+61", "code": "CC" }, { "name": "Congo, The Democratic Republic of the", "dial_code": "+243", "code": "CD" }, { "name": "Cote d'Ivoire", "dial_code": "+225", "code": "CI" }, { "name": "Falkland Islands (Malvinas)", "dial_code": "+500", "code": "FK" }, { "name": "Guernsey", "dial_code": "+44", "code": "GG" }, { "name": "Holy See (Vatican City State)", "dial_code": "+379", "code": "VA" }, { "name": "Hong Kong", "dial_code": "+852", "code": "HK" }, { "name": "Iran, Islamic Republic of", "dial_code": "+98", "code": "IR" }, { "name": "Isle of Man", "dial_code": "+44", "code": "IM" }, { "name": "Jersey", "dial_code": "+44", "code": "JE" }, { "name": "Korea, Democratic People's Republic of", "dial_code": "+850", "code": "KP" }, { "name": "Korea, Republic of", "dial_code": "+82", "code": "KR" }, { "name": "Lao People's Democratic Republic", "dial_code": "+856", "code": "LA" }, { "name": "Libyan Arab Jamahiriya", "dial_code": "+218", "code": "LY" }, { "name": "Macao", "dial_code": "+853", "code": "MO" }, { "name": "Macedonia, The Former Yugoslav Republic of", "dial_code": "+389", "code": "MK" }, { "name": "Micronesia, Federated States of", "dial_code": "+691", "code": "FM" }, { "name": "Moldova, Republic of", "dial_code": "+373", "code": "MD" }, { "name": "Mozambique", "dial_code": "+258", "code": "MZ" }, { "name": "Palestinian Territory, Occupied", "dial_code": "+970", "code": "PS" }, { "name": "Pitcairn", "dial_code": "+872", "code": "PN" }, { "name": "Réunion", "dial_code": "+262", "code": "RE" }, { "name": "Russia", "dial_code": "+7", "code": "RU" }, { "name": "Saint Barthélemy", "dial_code": "+590", "code": "BL" }, { "name": "Saint Helena, Ascension and Tristan Da Cunha", "dial_code": "+290", "code": "SH" }, { "name": "Saint Kitts and Nevis", "dial_code": "+1", "code": "KN" }, { "name": "Saint Lucia", "dial_code": "+1 758", "code": "LC" }, { "name": "Saint Martin", "dial_code": "+590", "code": "MF" }, { "name": "Saint Pierre and Miquelon", "dial_code": "+508", "code": "PM" }, { "name": "Saint Vincent and the Grenadines", "dial_code": "+1 784", "code": "VC" }, { "name": "Sao Tome and Principe", "dial_code": "+239", "code": "ST" }, { "name": "Somalia", "dial_code": "+252", "code": "SO" }, { "name": "Svalbard and Jan Mayen", "dial_code": "+47", "code": "SJ" }, { "name": "Syrian Arab Republic", "dial_code": "+963", "code": "SY" }, { "name": "Taiwan, Province of China", "dial_code": "+886", "code": "TW" }, { "name": "Tanzania, United Republic of", "dial_code": "+255", "code": "TZ" }, { "name": "Timor-Leste", "dial_code": "+670", "code": "TL" }, { "name": "Venezuela, Bolivarian Republic of", "dial_code": "+58", "code": "VE" }, { "name": "Viet Nam", "dial_code": "+84", "code": "VN" }, { "name": "Virgin Islands, British", "dial_code": "+1", "code": "VG" }, { "name": "Virgin Islands, U.S.", "dial_code": "+1", "code": "VI" }];

    $scope.dropDown = countryCode.list;
    console.log("dropdownnn", $scope.dropDown);
    $scope.phnRegex = /[^0][0-9]{5,}$/;
    // $scope.dropDown = [{ "name": "Israel", "dial_code": "+972", "code": "IL" }, { "name": "Afghanistan", "dial_code": "+93", "code": "AF" }, { "name": "Albania", "dial_code": "+355", "code": "AL" }, { "name": "Algeria", "dial_code": "+213", "code": "DZ" }, { "name": "AmericanSamoa", "dial_code": "+1", "code": "AS" }, { "name": "Andorra", "dial_code": "+376", "code": "AD" }, { "name": "Angola", "dial_code": "+244", "code": "AO" }, { "name": "Anguilla", "dial_code": "+1", "code": "AI" }, { "name": "Antigua and Barbuda", "dial_code": "+1268", "code": "AG" }, { "name": "Argentina", "dial_code": "+54", "code": "AR" }, { "name": "Armenia", "dial_code": "+374", "code": "AM" }, { "name": "Aruba", "dial_code": "+297", "code": "AW" }, { "name": "Australia", "dial_code": "+61", "code": "AU" }, { "name": "Austria", "dial_code": "+43", "code": "AT" }, { "name": "Azerbaijan", "dial_code": "+994", "code": "AZ" }, { "name": "Bahamas", "dial_code": "+1", "code": "BS" }, { "name": "Bahrain", "dial_code": "+973", "code": "BH" }, { "name": "Bangladesh", "dial_code": "+880", "code": "BD" }, { "name": "Barbados", "dial_code": "+1", "code": "BB" }, { "name": "Belarus", "dial_code": "+375", "code": "BY" }, { "name": "Belgium", "dial_code": "+32", "code": "BE" }, { "name": "Belize", "dial_code": "+501", "code": "BZ" }, { "name": "Benin", "dial_code": "+229", "code": "BJ" }, { "name": "Bermuda", "dial_code": "+1", "code": "BM" }, { "name": "Bhutan", "dial_code": "+975", "code": "BT" }, { "name": "Bosnia and Herzegovina", "dial_code": "+387", "code": "BA" }, { "name": "Botswana", "dial_code": "+267", "code": "BW" }, { "name": "Brazil", "dial_code": "+55", "code": "BR" }, { "name": "British Indian Ocean Territory", "dial_code": "+246", "code": "IO" }, { "name": "Bulgaria", "dial_code": "+359", "code": "BG" }, { "name": "Burkina Faso", "dial_code": "+226", "code": "BF" }, { "name": "Burundi", "dial_code": "+257", "code": "BI" }, { "name": "Cambodia", "dial_code": "+855", "code": "KH" }, { "name": "Cameroon", "dial_code": "+237", "code": "CM" }, { "name": "Canada", "dial_code": "+1", "code": "CA" }, { "name": "Cape Verde", "dial_code": "+238", "code": "CV" }, { "name": "Cayman Islands", "dial_code": "+ 345", "code": "KY" }, { "name": "Central African Republic", "dial_code": "+236", "code": "CF" }, { "name": "Chad", "dial_code": "+235", "code": "TD" }, { "name": "Chile", "dial_code": "+56", "code": "CL" }, { "name": "China", "dial_code": "+86", "code": "CN" }, { "name": "Christmas Island", "dial_code": "+61", "code": "CX" }, { "name": "Colombia", "dial_code": "+57", "code": "CO" }, { "name": "Comoros", "dial_code": "+269", "code": "KM" }, { "name": "Congo", "dial_code": "+242", "code": "CG" }, { "name": "Cook Islands", "dial_code": "+682", "code": "CK" }, { "name": "Costa Rica", "dial_code": "+506", "code": "CR" }, { "name": "Croatia", "dial_code": "+385", "code": "HR" }, { "name": "Cuba", "dial_code": "+53", "code": "CU" }, { "name": "Cyprus", "dial_code": "+537", "code": "CY" }, { "name": "Czech Republic", "dial_code": "+420", "code": "CZ" }, { "name": "Denmark", "dial_code": "+45", "code": "DK" }, { "name": "Djibouti", "dial_code": "+253", "code": "DJ" }, { "name": "Dominica", "dial_code": "+1", "code": "DM" }, { "name": "Dominican Republic", "dial_code": "+1", "code": "DO" }, { "name": "Ecuador", "dial_code": "+593", "code": "EC" }, { "name": "Egypt", "dial_code": "+20", "code": "EG" }, { "name": "El Salvador", "dial_code": "+503", "code": "SV" }, { "name": "Equatorial Guinea", "dial_code": "+240", "code": "GQ" }, { "name": "Eritrea", "dial_code": "+291", "code": "ER" }, { "name": "Estonia", "dial_code": "+372", "code": "EE" }, { "name": "Ethiopia", "dial_code": "+251", "code": "ET" }, { "name": "Faroe Islands", "dial_code": "+298", "code": "FO" }, { "name": "Fiji", "dial_code": "+679", "code": "FJ" }, { "name": "Finland", "dial_code": "+358", "code": "FI" }, { "name": "France", "dial_code": "+33", "code": "FR" }, { "name": "French Guiana", "dial_code": "+594", "code": "GF" }, { "name": "French Polynesia", "dial_code": "+689", "code": "PF" }, { "name": "Gabon", "dial_code": "+241", "code": "GA" }, { "name": "Gambia", "dial_code": "+220", "code": "GM" }, { "name": "Georgia", "dial_code": "+995", "code": "GE" }, { "name": "Germany", "dial_code": "+49", "code": "DE" }, { "name": "Ghana", "dial_code": "+233", "code": "GH" }, { "name": "Gibraltar", "dial_code": "+350", "code": "GI" }, { "name": "Greece", "dial_code": "+30", "code": "GR" }, { "name": "Greenland", "dial_code": "+299", "code": "GL" }, { "name": "Grenada", "dial_code": "+1", "code": "GD" }, { "name": "Guadeloupe", "dial_code": "+590", "code": "GP" }, { "name": "Guam", "dial_code": "+1", "code": "GU" }, { "name": "Guatemala", "dial_code": "+502", "code": "GT" }, { "name": "Guinea", "dial_code": "+224", "code": "GN" }, { "name": "Guinea-Bissau", "dial_code": "+245", "code": "GW" }, { "name": "Guyana", "dial_code": "+595", "code": "GY" }, { "name": "Haiti", "dial_code": "+509", "code": "HT" }, { "name": "Honduras", "dial_code": "+504", "code": "HN" }, { "name": "Hungary", "dial_code": "+36", "code": "HU" }, { "name": "Iceland", "dial_code": "+354", "code": "IS" }, { "name": "India", "dial_code": "+91", "code": "IN" }, { "name": "Indonesia", "dial_code": "+62", "code": "ID" }, { "name": "Iraq", "dial_code": "+964", "code": "IQ" }, { "name": "Ireland", "dial_code": "+353", "code": "IE" }, { "name": "Israel", "dial_code": "+972", "code": "IL" }, { "name": "Italy", "dial_code": "+39", "code": "IT" }, { "name": "Jamaica", "dial_code": "+1", "code": "JM" }, { "name": "Japan", "dial_code": "+81", "code": "JP" }, { "name": "Jordan", "dial_code": "+962", "code": "JO" }, { "name": "Kazakhstan", "dial_code": "+7", "code": "KZ" }, { "name": "Kenya", "dial_code": "+254", "code": "KE" }, { "name": "Kiribati", "dial_code": "+686", "code": "KI" }, { "name": "Kuwait", "dial_code": "+965", "code": "KW" }, { "name": "Kyrgyzstan", "dial_code": "+996", "code": "KG" }, { "name": "Latvia", "dial_code": "+371", "code": "LV" }, { "name": "Lebanon", "dial_code": "+961", "code": "LB" }, { "name": "Lesotho", "dial_code": "+266", "code": "LS" }, { "name": "Liberia", "dial_code": "+231", "code": "LR" }, { "name": "Liechtenstein", "dial_code": "+423", "code": "LI" }, { "name": "Lithuania", "dial_code": "+370", "code": "LT" }, { "name": "Luxembourg", "dial_code": "+352", "code": "LU" }, { "name": "Madagascar", "dial_code": "+261", "code": "MG" }, { "name": "Malawi", "dial_code": "+265", "code": "MW" }, { "name": "Malaysia", "dial_code": "+60", "code": "MY" }, { "name": "Maldives", "dial_code": "+960", "code": "MV" }, { "name": "Mali", "dial_code": "+223", "code": "ML" }, { "name": "Malta", "dial_code": "+356", "code": "MT" }, { "name": "Marshall Islands", "dial_code": "+692", "code": "MH" }, { "name": "Martinique", "dial_code": "+596", "code": "MQ" }, { "name": "Mauritania", "dial_code": "+222", "code": "MR" }, { "name": "Mauritius", "dial_code": "+230", "code": "MU" }, { "name": "Mayotte", "dial_code": "+262", "code": "YT" }, { "name": "Mexico", "dial_code": "+52", "code": "MX" }, { "name": "Monaco", "dial_code": "+377", "code": "MC" }, { "name": "Mongolia", "dial_code": "+976", "code": "MN" }, { "name": "Montenegro", "dial_code": "+382", "code": "ME" }, { "name": "Montserrat", "dial_code": "+1664", "code": "MS" }, { "name": "Morocco", "dial_code": "+212", "code": "MA" }, { "name": "Myanmar", "dial_code": "+95", "code": "MM" }, { "name": "Namibia", "dial_code": "+264", "code": "NA" }, { "name": "Nauru", "dial_code": "+674", "code": "NR" }, { "name": "Nepal", "dial_code": "+977", "code": "NP" }, { "name": "Netherlands", "dial_code": "+31", "code": "NL" }, { "name": "Netherlands Antilles", "dial_code": "+599", "code": "AN" }, { "name": "New Caledonia", "dial_code": "+687", "code": "NC" }, { "name": "New Zealand", "dial_code": "+64", "code": "NZ" }, { "name": "Nicaragua", "dial_code": "+505", "code": "NI" }, { "name": "Niger", "dial_code": "+227", "code": "NE" }, { "name": "Nigeria", "dial_code": "+234", "code": "NG" }, { "name": "Niue", "dial_code": "+683", "code": "NU" }, { "name": "Norfolk Island", "dial_code": "+672", "code": "NF" }, { "name": "Northern Mariana Islands", "dial_code": "+1", "code": "MP" }, { "name": "Norway", "dial_code": "+47", "code": "NO" }, { "name": "Oman", "dial_code": "+968", "code": "OM" }, { "name": "Pakistan", "dial_code": "+92", "code": "PK" }, { "name": "Palau", "dial_code": "+680", "code": "PW" }, { "name": "Panama", "dial_code": "+507", "code": "PA" }, { "name": "Papua New Guinea", "dial_code": "+675", "code": "PG" }, { "name": "Paraguay", "dial_code": "+595", "code": "PY" }, { "name": "Peru", "dial_code": "+51", "code": "PE" }, { "name": "Philippines", "dial_code": "+63", "code": "PH" }, { "name": "Poland", "dial_code": "+48", "code": "PL" }, { "name": "Portugal", "dial_code": "+351", "code": "PT" }, { "name": "Puerto Rico", "dial_code": "+1", "code": "PR" }, { "name": "Qatar", "dial_code": "+974", "code": "QA" }, { "name": "Romania", "dial_code": "+40", "code": "RO" }, { "name": "Rwanda", "dial_code": "+250", "code": "RW" }, { "name": "Samoa", "dial_code": "+685", "code": "WS" }, { "name": "San Marino", "dial_code": "+378", "code": "SM" }, { "name": "Saudi Arabia", "dial_code": "+966", "code": "SA" }, { "name": "Senegal", "dial_code": "+221", "code": "SN" }, { "name": "Serbia", "dial_code": "+381", "code": "RS" }, { "name": "Seychelles", "dial_code": "+248", "code": "SC" }, { "name": "Sierra Leone", "dial_code": "+232", "code": "SL" }, { "name": "Singapore", "dial_code": "+65", "code": "SG" }, { "name": "Slovakia", "dial_code": "+421", "code": "SK" }, { "name": "Slovenia", "dial_code": "+386", "code": "SI" }, { "name": "Solomon Islands", "dial_code": "+677", "code": "SB" }, { "name": "South Africa", "dial_code": "+27", "code": "ZA" }, { "name": "South Georgia and the South Sandwich Islands", "dial_code": "+500", "code": "GS" }, { "name": "Spain", "dial_code": "+34", "code": "ES" }, { "name": "Sri Lanka", "dial_code": "+94", "code": "LK" }, { "name": "Sudan", "dial_code": "+249", "code": "SD" }, { "name": "Suriname", "dial_code": "+597", "code": "SR" }, { "name": "Swaziland", "dial_code": "+268", "code": "SZ" }, { "name": "Sweden", "dial_code": "+46", "code": "SE" }, { "name": "Switzerland", "dial_code": "+41", "code": "CH" }, { "name": "Tajikistan", "dial_code": "+992", "code": "TJ" }, { "name": "Thailand", "dial_code": "+66", "code": "TH" }, { "name": "Togo", "dial_code": "+228", "code": "TG" }, { "name": "Tokelau", "dial_code": "+690", "code": "TK" }, { "name": "Tonga", "dial_code": "+676", "code": "TO" }, { "name": "Trinidad and Tobago", "dial_code": "+1", "code": "TT" }, { "name": "Tunisia", "dial_code": "+216", "code": "TN" }, { "name": "Turkey", "dial_code": "+90", "code": "TR" }, { "name": "Turkmenistan", "dial_code": "+993", "code": "TM" }, { "name": "Turks and Caicos Islands", "dial_code": "+1", "code": "TC" }, { "name": "Tuvalu", "dial_code": "+688", "code": "TV" }, { "name": "Uganda", "dial_code": "+256", "code": "UG" }, { "name": "Ukraine", "dial_code": "+380", "code": "UA" }, { "name": "United Arab Emirates", "dial_code": "+971", "code": "AE" }, { "name": "United Kingdom", "dial_code": "+44", "code": "GB" }, { "name": "United States", "dial_code": "+1", "code": "US" }, { "name": "Uruguay", "dial_code": "+598", "code": "UY" }, { "name": "Uzbekistan", "dial_code": "+998", "code": "UZ" }, { "name": "Vanuatu", "dial_code": "+678", "code": "VU" }, { "name": "Wallis and Futuna", "dial_code": "+681", "code": "WF" }, { "name": "Yemen", "dial_code": "+967", "code": "YE" }, { "name": "Zambia", "dial_code": "+260", "code": "ZM" }, { "name": "Zimbabwe", "dial_code": "+263", "code": "ZW" }, { "name": "land Islands", "dial_code": "", "code": "AX" }, { "name": "Antarctica", "dial_code": null, "code": "AQ" }, { "name": "Bolivia, Plurinational State of", "dial_code": "+591", "code": "BO" }, { "name": "Brunei Darussalam", "dial_code": "+673", "code": "BN" }, { "name": "Cocos (Keeling) Islands", "dial_code": "+61", "code": "CC" }, { "name": "Congo, The Democratic Republic of the", "dial_code": "+243", "code": "CD" }, { "name": "Cote d'Ivoire", "dial_code": "+225", "code": "CI" }, { "name": "Falkland Islands (Malvinas)", "dial_code": "+500", "code": "FK" }, { "name": "Guernsey", "dial_code": "+44", "code": "GG" }, { "name": "Holy See (Vatican City State)", "dial_code": "+379", "code": "VA" }, { "name": "Hong Kong", "dial_code": "+852", "code": "HK" }, { "name": "Iran, Islamic Republic of", "dial_code": "+98", "code": "IR" }, { "name": "Isle of Man", "dial_code": "+44", "code": "IM" }, { "name": "Jersey", "dial_code": "+44", "code": "JE" }, { "name": "Korea, Democratic People's Republic of", "dial_code": "+850", "code": "KP" }, { "name": "Korea, Republic of", "dial_code": "+82", "code": "KR" }, { "name": "Lao People's Democratic Republic", "dial_code": "+856", "code": "LA" }, { "name": "Libyan Arab Jamahiriya", "dial_code": "+218", "code": "LY" }, { "name": "Macao", "dial_code": "+853", "code": "MO" }, { "name": "Macedonia, The Former Yugoslav Republic of", "dial_code": "+389", "code": "MK" }, { "name": "Micronesia, Federated States of", "dial_code": "+691", "code": "FM" }, { "name": "Moldova, Republic of", "dial_code": "+373", "code": "MD" }, { "name": "Mozambique", "dial_code": "+258", "code": "MZ" }, { "name": "Palestinian Territory, Occupied", "dial_code": "+970", "code": "PS" }, { "name": "Pitcairn", "dial_code": "+872", "code": "PN" }, { "name": "Réunion", "dial_code": "+262", "code": "RE" }, { "name": "Russia", "dial_code": "+7", "code": "RU" }, { "name": "Saint Barthélemy", "dial_code": "+590", "code": "BL" }, { "name": "Saint Helena, Ascension and Tristan Da Cunha", "dial_code": "+290", "code": "SH" }, { "name": "Saint Kitts and Nevis", "dial_code": "+1", "code": "KN" }, { "name": "Saint Lucia", "dial_code": "+1 758", "code": "LC" }, { "name": "Saint Martin", "dial_code": "+590", "code": "MF" }, { "name": "Saint Pierre and Miquelon", "dial_code": "+508", "code": "PM" }, { "name": "Saint Vincent and the Grenadines", "dial_code": "+1 784", "code": "VC" }, { "name": "Sao Tome and Principe", "dial_code": "+239", "code": "ST" }, { "name": "Somalia", "dial_code": "+252", "code": "SO" }, { "name": "Svalbard and Jan Mayen", "dial_code": "+47", "code": "SJ" }, { "name": "Syrian Arab Republic", "dial_code": "+963", "code": "SY" }, { "name": "Taiwan, Province of China", "dial_code": "+886", "code": "TW" }, { "name": "Tanzania, United Republic of", "dial_code": "+255", "code": "TZ" }, { "name": "Timor-Leste", "dial_code": "+670", "code": "TL" }, { "name": "Venezuela, Bolivarian Republic of", "dial_code": "+58", "code": "VE" }, { "name": "Viet Nam", "dial_code": "+84", "code": "VN" }, { "name": "Virgin Islands, British", "dial_code": "+1", "code": "VG" }, { "name": "Virgin Islands, U.S.", "dial_code": "+1", "code": "VI" }];

    $scope.user = {};
    $scope.user.covering = [];
    $scope.covering = '';
    $scope.min = 1;
    $scope.max = 500;
    $scope.checked = true;
    $scope.example8settings = {
        checkBoxes: true,
    };
    $scope.userCookieDetailsUpload = $cookieStore.get('profileDetails');


    //-------------------------------------SUGGESTION FORM POPUP---------------------------------------
    $scope.SuggestionFormPopup = function () {
        ngDialog.open({
            template: 'suggestion-form'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }

    //-------------------------------------SUGGESTION FORM POPUP---------------------------------------
    //  $scope.afterClickButton=false;
    $scope.suggestion = function () {
        $scope.afterClickButton = true;
        var fd = new FormData()
        fd.append("suggestion", $scope.user.suggestion);
        $http({
            url: MY_CONSTANT.url + '/user/suggestion',
            method: 'POST',
            headers: {
                'Content-type': undefined,
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            },
            data: fd
        }).success(function (response) {
            $scope.afterClickButton = false;
            $scope.user = {};
            ngDialog.close();
            $scope.suggestionMsg = "Suggestion submitted successfully"
            ngDialog.open({
                template: 'suggestion-msg'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            $timeout(function () {
                ngDialog.close();
                //  $state.reload();
                //$state.go('app.upload');
            }, 2000);

        }).error(function (response) {
            $scope.afterClickButton = false;
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        })
    }


    //-------------------------------------GET USER DETAILS---------------------------------------
    $scope.getDetails = function () {
        $scope.loading = true;
        $http({
            url: MY_CONSTANT.url + '/user/getDetails'
            , method: 'GET'
            , headers: {
                authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            console.log(" get ", response);

            $scope.loading = false;
            if (response.data.user.isDetailsFilled == true) {
                $state.go('app.videographerDashboard');
            }
            else {
                if (response.statusCode == 200) {
                    var user1 = response.data.user;
                    $scope.user = {
                        "name": user1.name
                        , "location": user1.address.city
                        , "profilePictureURL": user1.profilePictureURL
                        , "company": user1.videographer.companyName
                        , "aboutme": user1.videographer.aboutMe
                        , "experince": parseInt(user1.videographer.experience)
                        , "pricehour": user1.videographer.hourlyRate
                        , "username": user1.name
                        , "email": user1.email
                        , "distance": parseInt(user1.videographer.distance)
                        , "questions": user1.questions
                        , "countryCode": user1.countryCode ? user1.countryCode : '+1'
                        , "cellno": user1.cellNumber
                        , "phoneno": user1.phoneNumber
                        //  "covering":user1.videographer.categoryOfCoverings[0]._id
                    }
                    if (!user1.name) {
                        $scope.user.name = $scope.userCookieDetailsUpload.name;
                    }
                    if (!user1.email) {
                        $scope.user.email = $scope.userCookieDetailsUpload.email;
                    }
                    if (user1.profilePictureURL == null || user1.profilePictureURL == '' || user1.profilePictureURL == ' ') {
                        $scope.user.profilePictureURL = $scope.userCookieDetailsUpload.profilePictureURL;
                    }
                    if (user1.videographer.categoryOfCoverings.length != 0) {
                        $scope.user.covering = user1.videographer.categoryOfCoverings[0].categoryId;
                    }
                    // $scope.covering = user1.videographer.categoryOfCoverings[0]._id;
                    $scope.lat = user1.address.latitude;
                    $scope.lng = user1.address.longitude;
                    $scope.city = user1.address.city;
                    $scope.country = user1.address.country;
                }
            }
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.getDetails();
    ///=========================================Multiple Select=============================///////
    $(".dropdown dt a").on('click', function () {
        $(".dropdown dd ul").slideToggle('fast');
    });
    $(".dropdown dd ul li a").on('click', function () {
        $(".dropdown dd ul").hide();
    });

    function getSelectedValue(id) {
        return $("#" + id).find("dt a span.value").html();
    }
    $(document).bind('click', function (e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("dropdown")) $(".dropdown dd ul").hide();
    });
    $('.mutliSelect input[type="checkbox"]').on('click', function () {
        var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val()
            , title = $(this).val() + ",";
        if ($(this).is(':checked')) {
            var html = '<span title="' + title + '">' + title + '</span>';
            $('.multiSel').append(html);
            $(".hida").hide();
        }
        else {
            $('span[title="' + title + '"]').remove();
            var ret = $(".hida");
            $('.dropdown dt a').append(ret);
        }
    });
    //    
    //    $scope.clearSearch = function() {
    //    $scope.user.image = null;
    //}
    ///=========================================Checkbox checked Limited=============================///////    
    // $scope.catelength = 0;
    // $scope.checkedItems = [];
    // $scope.checkedCount = 0;
    // $scope.checkedID = [];
    // $scope.checkedlabel = [];
    // angular.forEach($scope.items, function (item, itemid, itemlabel) {
    //     if (item.checked === true) {
    //         $scope.checkedCount++;
    //         $scope.checkedItems.push(item.id);
    //         $scope.checkedID.push(itemid);
    //         $scope.checkedlabel.push(itemlabel);
    //     }
    // });
    // $scope.checkedFun = function (item, itemid, itemlabel) {
    //     if (item.checked) {
    //         $scope.checkedCount++;
    //         item.checked = true;
    //         $scope.checkedItems.push(item.id);
    //         $scope.catlength = $scope.checkedItems.length;
    //         $scope.checkedID.push(itemid);
    //         $scope.checkedlabel.push(itemlabel);
    //     }
    //     else {
    //         $scope.checkedCount--;
    //         item.checked = false;
    //         var findId = $scope.checkedItems.indexOf(item.id);
    //         $scope.checkedItems.splice(findId, 1);
    //         var findId2 = $scope.checkedID.indexOf(itemid);
    //         $scope.checkedID.splice(findId2, 1);
    //         var findId3 = $scope.checkedlabel.indexOf(itemlabel);
    //         $scope.checkedlabel.splice(findId3, 1);
    //         $scope.catlength = $scope.checkedItems.length;
    //     };
    //     $scope.checkedname = $scope.checkedlabel.toString();
    //     if ($scope.catlength === '' || $scope.catlength === undefined) {
    //         $scope.catelength = 0;
    //     }
    //     else {
    //         $scope.catelength = 1;
    //     };
    // };

    $scope.catelength = 0;
    $scope.checkedItems = [];
    $scope.checkedCount = 0;
    $scope.checkedID = [];
    $scope.checkedlabel = [];
    angular.forEach($scope.items, function (item, itemid, itemlabel) {
        if (item.checked === true) {
            $scope.checkedCount++;
            $scope.checkedItems.push(item.id);
            $scope.checkedID.push(itemid);
            $scope.checkedlabel.push(itemlabel);
        }
    });
    $scope.checkedFun = function (item, itemid, itemlabel) {
        if (item.checked) {
            $scope.checkedCount++;
            item.checked = true;
            $scope.checkedItems.push(item.id);
            $scope.catlength = $scope.checkedItems.length;
            $scope.checkedID.push(itemid);
            $scope.checkedlabel.push(itemlabel);
        }
        else {
            $scope.checkedCount--;
            item.checked = false;
            var findId = $scope.checkedItems.indexOf(item.id);
            $scope.checkedItems.splice(findId, 1);
            var findId2 = $scope.checkedID.indexOf(itemid);
            $scope.checkedID.splice(findId2, 1);
            var findId3 = $scope.checkedlabel.indexOf(itemlabel);
            $scope.checkedlabel.splice(findId3, 1);
            $scope.catlength = $scope.checkedItems.length;
        };
        $scope.checkedname = $scope.checkedlabel.toString();
        if ($scope.catlength === '' || $scope.catlength === undefined) {
            $scope.catelength = 0;
        }
        else {
            $scope.catelength = 1;
        };
    };






    //-------------------------------------POPULATING SELECT DROPDOWN---------------------------------------
    ngDialog.closeAll();
    $scope.category = function () {
        $http({
            url: MY_CONSTANT.url + '/category/getAllCategories'
            , method: 'GET'
        }).success(function (response) {
            if (response.statusCode == 200) {
                $scope.list = response.data;
                var tmp = [];
                $scope.idlistarray = [];
                angular.forEach(response.data, function (col) {
                    tmp.push({
                        id: col._id
                        , label: col.categoryName
                    })
                });
                $scope.list = tmp;
            }
        }).error(function (response) {
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: trueclick
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
        })
    }
    $scope.category();
    //////////////////////=============================FILE UPLOAD============================//////////////////////
    $scope.file_to_upload = function (File, name) {
        if (name == "category") {
            var file = File[0];
            var imageType = /image.*/;
            if (!file.type.match(imageType)) {
                document.getElementById("categoryImage").value = null;
                return;
            }
            else {
                var transcript = File[0];
                var reader = new FileReader;
                reader.onload = function (e) {
                    var img = new Image;
                    $('#abcfg').attr('src', e.target.result);
                    img.onload = function () {
                        $scope.FileUploaded = File[0];
                    };
                    img.src = reader.result;
                };
                reader.readAsDataURL(transcript);
            }
        }
    };
    $scope.cancelImage = function (id) {
        $('#' + id).attr('src', 'app/img/no-profile-image.png');
        $scope.FileUploaded = 'app/img/no-profile-image.png';
        $scope.user.profilePictureURL = 'app/img/no-profile-image.png';
    }
    /////////////////////=============================PDF UPLOAD============================//////////////////////
    $scope.file_pdf_upload = function (File, name) {
        console.log('File', File);
        $scope.file = File[0];
        $scope.user.pdf = File[0].name;
        $scope.$apply();
    };
    $scope.cancelw9 = function () {
        $scope.user.pdf = '';
    }
    //////////////////////=============================PDF UPLOAD============================//////////////////////
    $scope.file_doc_upload = function (File, name) {
        console.log('File', File);
        $scope.file = File[0];
        $scope.user.doc = File[0].name;
        $scope.$apply();
    };
    //////////////////////=============================PDF UPLOAD============================//////////////////////
    $scope.file_upload = function (File, type) {
        if (type == 1) {
            console.log('File pdf', File);
            $scope.user.pdf = File[0];
            $scope.user.pdfName = File[0].name;
            $scope.sendPdf = true;
            console.log($scope.sandPdf);
            $scope.$apply();
        }
        else if (type == 2) {
            console.log('File doc', File);
            $scope.user.doc = File[0];
            $scope.user.docName = File[0].name;
            $scope.sendDoc = true;
            console.log($scope.sandDoc);
            $scope.$apply();
        }
    };
    //////////////////////=============================cleardoc============================//////////////////////
    $scope.cleardoc = function () {
        $scope.user.doc = ' ';
        $scope.user.docName = ' ';
        $scope.sendDoc = true;
        console.log($scope.user.doc)
    }
    ///=========================================UPLOAD VIDEOGRAPHER DETAILS=============================///////
    //    $scope.saveuploadDetails = function (user, valid) {
    //        angular.element('.afterlogin input.ng-invalid,select.ng-invalid,textarea.ng-invalid').first().focus();
    //        if (valid) {
    //            $scope.loading = true;
    //            var location = document.getElementById('address').value;
    //            var splited = location.split(",");
    //            var country = splited[splited.length - 1];
    //            splited = splited.splice(0, splited.length - 1);
    //            var city = splited.join(",");
    //            var catIds = [];
    //            var catNames=[];
    //            for (var i = 0; i < $scope.checkedID.length; i++) {
    //                catIds.push({
    //                    'categoryId': $scope.checkedID[i]
    //                });
    //            }
    //            //  for (var i = 0; i < $scope.checkedlabel.length; i++) {
    //            //     catNames.push({
    //            //         'categoryNames': $scope.checkedlabel[i]
    //            //     });
    //            // }
    //              for (var i = 0; i < $scope.checkedlabel.length; i++) {
    //                catNames.push($scope.checkedlabel[i]);
    //            }
    //            var tmp = [];
    //            tmp.push({
    //                'categoryId': $scope.user.covering
    //            });
    //            var fd = new FormData();
    //            fd.append("name", user.name);
    //            // if($scope.lat=='undefined'||$scope.lng=='undefined'){
    //            //     $scope.locationMsg='Please Enter Valid Location'
    //                //  ngDialog.open({
    //                //       template: 'wrong-location-msg'
    //                //     , className: 'ngdialog-theme-default commandialog'
    //                //     , showClose: true
    //                //     , closeByDocument: false
    //                //     , closeByEscape: false
    //                //     , scope: $scope
    //                // });    
    //            // }
    //            fd.append("latitude", $scope.lat);
    //            fd.append("longitude", $scope.lng);
    //            fd.append("city", city);
    //            fd.append("country", country);
    //            
    //            if ($scope.FileUploaded && $scope.FileUploaded != '') {
    //                fd.append("profilePictureURL", $scope.FileUploaded);
    //            }
    //            
    //            
    //            if (user.company && user.company != '') {
    //                fd.append("companyName", user.company);
    //            }
    //            fd.append("aboutMe", user.aboutme);
    //            if (user.experince && user.experince != '') {
    //                fd.append("experience", user.experince);
    //            }
    //            fd.append("hourlyRate", user.pricehour);
    //            fd.append("distance", user.distance);
    //            if (user.questions && user.questions != '') {
    //                fd.append("questions", user.questions);
    //            }
    //            if (user.countryCode && user.countryCode != '') {
    //                fd.append("countryCode", user.countryCode);
    //            }
    //            if (user.cellno && user.cellno != '') {
    //                fd.append("cellNumber", user.cellno);
    //            }
    //            fd.append("phoneNumber", user.phoneno);
    //            if (user.skills && user.skills != '') {
    //                fd.append("skills", user.skills);
    //            }
    //            if (user.websiteurl && user.websiteurl != '') {
    //                fd.append("websiteUrl", user.websiteurl);
    //            }
    //            if (catIds.length != 0) {
    //                fd.append("categoryOfCoverings", JSON.stringify(catIds));
    //                // fd.append("categoryNames", JSON.stringify(catNames));
    //            }
    //            if(catNames.length!=0){
    //                fd.append("categoryNames", JSON.stringify(catNames));    
    //            }
    //
    //            $http({
    //                url: MY_CONSTANT.url + '/videographer/updateVideographer'
    //                , method: 'PUT'
    //                , headers: {
    //                    'Content-type': undefined
    //                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
    //                }
    //                , data: fd
    //            }).success(function (response) {
    //                $scope.loading = false;
    //                if (response.statusCode == 200) {
    //                    var obj = $cookieStore.get('obj');
    //                    var profileDetails = $cookieStore.get('profileDetails');
    //                    if (response.data.user.name && response.data.user.name != '')
    //                        profileDetails.name = response.data.user.name;
    //                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '')
    //                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
    //                    $cookieStore.put('profileDetails', profileDetails);
    //                    $rootScope.$broadcast('picupload');
    //                    ngDialog.open({
    //                        template: 'success'
    //                        , className: 'ngdialog-theme-default commandialog'
    //                        , showClose: true
    //                        , closeByDocument: false
    //                        , closeByEscape: false
    //                        , scope: $scope
    //                    });
    //                    if ($cookieStore.get('searchdata')) {
    //                        $timeout(function(){
    //                             $state.go('app.search');
    //
    //                        },2000);         
    //                    }
    //                    else {
    //                         $timeout(function(){
    //                            $state.go('app.videographerDashboard');
    //                        },2000);
    //                    }
    //                }
    //            }).error(function (response) {
    //                $scope.loading = false;
    //                $scope.message = response.message;
    //                ngDialog.open({
    //                    template: 'error'
    //                    , className: 'ngdialog-theme-default commandialog'
    //                    , showClose: true
    //                    , closeByDocument: false
    //                    , closeByEscape: false
    //                    , scope: $scope
    //                });
    //            })
    //        }
    //    }
    //    
    $scope.saveuploadDetails = function (user, valid) {
        console.log(user)
        console.log(valid)
        angular.element('.afterlogin input.ng-invalid,select.ng-invalid,textarea.ng-invalid').first().focus();
        if (valid) {
            var location = document.getElementById('address').value;
            var splited = location.split(",");
            var country = splited[splited.length - 1];
            splited = splited.splice(0, splited.length - 1);
            var city = splited.join(",");
            if (!$scope.lat || !$scope.lng || !country || !city) {
                $scope.message = 'Please enter valid location';
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            }
            else {
                console.log("fgdfgdfdfg");
               var catIds = [];
                var catNames = [];
                for (var i = 0; i < $scope.checkedID.length; i++) {
                    catIds.push({
                        'categoryId': $scope.checkedID[i]
                    });
                }
                console.log("catIds" + catIds);

                for (var i = 0; i < $scope.checkedlabel.length; i++) {
                    catNames.push($scope.checkedlabel[i]);
                }
                console.log("catIds" + catNames);
                var tmp = [];
                tmp.push({
                    'categoryId': $scope.user.covering
                });
                var fd = new FormData();
                fd.append("name", user.name);
                fd.append("latitude", $scope.lat);
                fd.append("longitude", $scope.lng);
                fd.append("city", city);
                fd.append("country", country);
                fd.append("W9", $scope.user.pdf);
                fd.append("insurancePolicy", $scope.user.doc);

                if ($scope.user.countryCode == "" || $scope.user.countryCode == undefined) {
                    fd.append("countryCode", '+1'); alert("1")
                }
                if ($scope.FileUploaded == '' || $scope.FileUploaded == undefined) {
                    fd.append("profilePictureURL", $scope.user.profilePictureURL);
                }
                else {
                    fd.append("profilePictureURL", $scope.FileUploaded);
                }
                if (user.company && user.company != '') {
                    fd.append("companyName", user.company);
                }
                fd.append("aboutMe", user.aboutme);
                fd.append("distance", user.distance);
                if (user.countryCode && user.countryCode != '') {
                    fd.append("countryCode", user.countryCode);
                }
                if (user.cellno && user.cellno != '') {
                    fd.append("cellNumber", user.cellno);
                }
                fd.append("phoneNumber", user.phoneno);
                if (user.experince && user.experince != '') {
                    fd.append("experience", user.experince);
                }
                fd.append("hourlyRate", user.pricehour);
                if (user.questions && user.questions != '') {
                    fd.append("questions", user.questions);
                }
                if (user.skills && user.skills != '') {
                    fd.append("skills", user.skills);
                }
                if (user.websiteurl && user.websiteurl != '') {
                    fd.append("websiteUrl", user.websiteurl);
                }
                // fd.append("tags",JSON.stringify(res));   
                if (catIds.length != 0) {
                    fd.append("categoryOfCoverings", JSON.stringify(catIds));
                }
                if (catNames.length != 0) {
                    fd.append("categoryNames", JSON.stringify(catNames));
                }
                $http({
                    url: MY_CONSTANT.url + '/videographer/updateVideographer'
                    , method: 'PUT'
                    , headers: {
                        'Content-type': undefined
                        , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                    }
                    , data: fd
                }).success(function (response) {
                    if (response.statusCode == 200) {
                        var profileDetails = $cookieStore.get('profileDetails');
                        if (response.data.user.name && response.data.user.name != '') profileDetails.name = response.data.user.name;
                        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                        $cookieStore.put('profileDetails', profileDetails);
                        $rootScope.$broadcast('picupload');
                        $scope.ProfileSuccessMsg = "Profile Details Added Successfully";
                        ngDialog.open({
                            template: 'profile-success',
                             className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                        $timeout(function () {
                            $state.go('app.videographerDashboard');
                        }, 2000)
                    }
                }).error(function (response) {
                    console.log("responsee",response);
                    $scope.message = response.message;
                      console.log("responsee",response);
                    $scope.$apply();
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });

                    if (response.statusCode == 401) {
                        $state.go('page.mainLanding');
                    }

                })
            }
        }
    }
    //=================Function for autofill address=====================
    var markerArr = new Array();
    var markerArr1 = new Array();
    var autocomplete;

    function initAutocomplete() {
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('address')), {
            types: ['(cities)']
        });
        autocomplete.addListener('place_changed', fillInAddress);
    }

    function fillInAddress() {
        var place = autocomplete.getPlace().formatted_address;
        $timeout(function () {
            $scope.map = {
                zoom: 14
                , center: new google.maps.LatLng(30.718868, 76.810499)
                , pan: true
            };
            $scope.mapContainer = new google.maps.Map(document.getElementById('map-container'), $scope.map);
            $scope.deliveryAddressMarker(place);
        }, 1000)
    }
    initAutocomplete();
    $scope.closeAddressDialog = function () {
        $('#assign-address').modal('hide');
    };
    //=========================add marker on delivery address==========================
    $scope.deliveryAddressMarker = function (address) {
        $scope.registration.address = $('#address').val();
        $scope.showAddress = $('#address').val();
        (new google.maps.Geocoder()).geocode({
            'address': address
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                $scope.lat = results[0].geometry.location.lat();
                $scope.lng = results[0].geometry.location.lng();
                $scope.map = {
                    zoom: 14
                    , center: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())
                    , pan: true
                };
                var panPoint = new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng());
                $scope.latlng1 = results[0].geometry.location.lat();
                $scope.latlng2 = results[0].geometry.location.lng();
                $scope.mapContainer.panTo(panPoint);
                var icon = 'app/img/redMarker.png';
                if (markerArr.length) {
                    for (i = 0; i < markerArr.length; i++) markerArr[i].setMap(null);
                    markerArr.pop();
                }
                var marker = new google.maps.Marker({
                    map: $scope.mapContainer
                    , icon: icon
                    , position: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng())
                    , draggable: true
                });
                google.maps.event.addListener(marker, 'drag', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
                google.maps.event.addListener(marker, 'dragend', function () {
                    $scope.reverseGeocode(marker.getPosition(), 0);
                    $scope.latlng1 = marker.getPosition().lat();
                    $scope.latlng2 = marker.getPosition().lng();
                });
            }
            else {
                $scope.displaymsg = 'Delivery address is not valid';
                ngDialog.open({
                    template: 'display_msg_modalDialog1'
                    , className: 'ngdialog-theme-default'
                    , showClose: false
                    , scope: $scope
                });
            }
        });
    };
    //=========================place marker on given lat lng==========================
    $scope.placeMarker = function (lat, long) {
        var icon = 'app/img/redMarker.png';
        var marker = new google.maps.Marker({
            map: $scope.mapContainer
            , icon: icon
            , position: new google.maps.LatLng(lat, long)
            , draggable: true
        });
        if (markerArr.length) {
            for (var i = 0; i < markerArr.length; i++) markerArr[i].setMap(null);
            markerArr.pop();
        }
        markerArr.push(marker);
        google.maps.event.addListener(marker, 'drag', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
        google.maps.event.addListener(marker, 'dragend', function () {
            $scope.reverseGeocode(marker.getPosition(), 0);
        });
    };
    //=========================reverse geocode to get address==========================
    $scope.reverseGeocode = function (latlong) {
        (new google.maps.Geocoder()).geocode({
            'latLng': latlong
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    $('#address').val(results[0].formatted_address);
                    $scope.registration.address = results[0].formatted_address;
                    $scope.showAddress = results[0].formatted_address;
                    $scope.$apply();
                }
            }
        });
    };
})