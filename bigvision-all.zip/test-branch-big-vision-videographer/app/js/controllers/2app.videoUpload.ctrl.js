/**
 * Created by admin-in on 21/4/17.
 */
App.controller('VideoUploadController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $log, $sce, jwplayerService) {
    "use strict";
    
    
    

    
        
    
    $scope.selectProjectId = $stateParams.id;
    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    console.log($scope.proTitle);
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        console.log("small" + $scope.projectTime);
    }
    
    
    
    
    
//post /user/uploadFile 
    
    
    
    
    
    $scope.user = {};
    $scope.userId = "591eefb14d1fcf7efa44b63a";
    $scope.mediaurl = "";
    $scope.ngDialog = ngDialog;
    $scope.loading = false;
    //////////////////////=============================UPLOAD Video============================//////////////////////
    $scope.file_upload = function (File, type) {
//        $scope.loading = true;
        if (type == 1) {
            console.log('File pdf', File);
            $scope.user.pdf = File[0];
            $scope.user.pdfName = File[0].name;
            ////        $scope.sendPdf = true;
            //        console.log("file path" + $scope.sandPdf);
            $scope.$apply();
            console.log("upload");
        }
        else if (type == 2) {
            console.log('File doc', File);
            $scope.user.doc = File[0];
            $scope.user.docName = File[0].name;
            $scope.sendDoc = true;
            console.log($scope.sandDoc);
            $scope.$apply();
        }
    };
    //////////////////////=============================cleardoc============================//////////////////////
    //-------------------------------------Get  Video---------------------------------------  
    $scope.getIt = function () {
        console.log("inside getvideo");
        $http({
            method: 'GET'
            , url: MY_CONSTANT.url + '/user/getMedia?userId=' + $scope.userId
            , headers: {
                'Content-type': undefined
            }
        }).success(function (response) {
            console.log(response);
            $scope.mediaurl = response[0].mediaURL;
        }).error(function (response) {
            console.log(response);
        })
    }
    $scope.getIt();
    
    
    $scope.playVideo = function () {
        $scope.name1 = 'JWPlayer Player 1';
        $scope.options1 = {
            type: 'mp4'
            , image: "http://i.imgur.com/zvxpTRK.jpg"
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        $scope.file1 = $sce.trustAsResourceUrl($scope.mediaurl);
    }
    
    $scope.showVideoPlayerPopup = function (video_path) {
        ngDialog.open({
            animation: true
            , scope: $scope
            , template: 'videographerplayer'
            , className: 'ngdialog-theme-default videopopup'
            , closeByDocument: true
        });
        $scope.$on('ngDialog.opened', function (e, $dialog) {
            $scope.playVideo();
            console.log('ngDialog opened: ' + $dialog.attr('id'));
        });
    }
    
    $timeout(function () {
        $scope.name = 'JWPlayer Player ';
       
            $scope.options = {
            type: 'mp4'
            , image: "http://i.imgur.com/zvxpTRK.jpg"
            , skin: {
                active: '#bc2131'
                , background: '#000000'
                , inactive: '#fff'
            , }
        };
        
        $scope.file = $sce.trustAsResourceUrl($scope.mediaurl);
        $scope.$on('ng-jwplayer-ready', function (event, args) {
            $log.info('Player ' + args.playerId + ' ready. Playing video');
            var player = jwplayerService.myPlayer[args.playerId];
            player.getFullscreen(true);
        });
    }, 1000);
    
    $scope.uploadVideoPopup = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'videographer-UploadVideo',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }
    
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    
    }
        
 
        
//-------------------------------------UPLOAD Video---------------------------------------

    $scope.uploadVideo = function (user) {
                    var fd = new FormData();
                    fd.append('mediaFile', $scope.user.pdf);
                    fd.append('projectId', '591eefb14d1fcf7efa44b63a');
                    $http({
                        url: MY_CONSTANT.url + '/user/uploadFile'
                        , method: 'POST'
                        , headers: {
                            'Content-type': undefined
                            , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                        }
                        , data: fd
                        , transformRequest: angular.identity
                    }).success(function (response) {
                        console.log(response);
                        $scope.loading = false;
                        //                        $scope.getIt();
                        //                        $state.reload();
                    }).error(function (response) {
                        console.log(response);
                    })
                }
    
    
    
             
    $scope.saveuploadVideo = function () {
      var fd = new FormData();
        
      fd.append('mediaFile', $scope.user.pdf);
      fd.append('projectId', $scope.projectId);
      $http({
          url: MY_CONSTANT.url + '/user/uploadFile'
          , method: 'POST'
          , headers: {
              'Content-type': undefined
              , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
          }
          , data: fd
          , transformRequest: angular.identity
      }).success(function (response) {
          console.log(response);
          $scope.loading = false;
          //                        $scope.getIt();
          //                        $state.reload();
      }).error(function (response) {
          console.log(response);
      })
  }
        
        
       
    
    
})