App.controller('EditQuotesController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog) {
    "use strict";
    $scope.numberRegex = /^[0-9]+$/;
    $scope.amountRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.alphaRegex = /^[a-zA-z]{1,}$/;
    $scope.quote = {};
    $scope.alphaRegexx = /^[a-zA-Z ]{2,30}$/;
    $scope.quotetxt = {}
    $scope.editform = {}
    $scope.itemamount = 0;
    $scope.editItemAmount = 0;
    $scope.videographerId = $stateParams.id;
    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    $scope.budgetRegex = /^[1-9]{1,10}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        console.log("small" + $scope.projectTime);
    }
    console.log($cookieStore.get('obj').accessToken);
    console.log($scope.projectId);
    ///=========================================Submit Add Items=============================///////
    $scope.submitAddItems = function (quote, form) {
            $scope.afterClickButton = true;
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("itemName", $scope.quote.itemName);
            fd.append("unit", $scope.quote.unit);
            fd.append("unitPrice", $scope.quote.unitPrice);
            fd.append("quantity", $scope.quote.quantity);
            fd.append("itemDesc", $scope.quote.description);
            fd.append("amount", $scope.quote.itemamount);
            $http({
                url: MY_CONSTANT.url + '/bidding/addItems'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    ngDialog.closeAll();
                    $scope.quote = {};
                    form.$setPristine();
                    $scope.SuccessMsg = "Item Added Successfully";
                    ngDialog.open({
                        template: 'success'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: false
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            }).error(function (response) {
                $scope.loading = false;
                $scope.ErrorMsg = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                
             if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
                
            })
        }
    ///=========================================Submit Add Items=============================///////      
    $scope.getBiddingItem = function () {
        $http({
            url: MY_CONSTANT.url + '/bidding/getBiddings?projectId=' + $scope.projectId
            , method: 'GET'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            console.log("response - " ,response.data[0].note);
            
            
            $scope.list = response.data[0].items;
                     
            $scope.quotetxt.note = response.data[0].note;
            
            
            console.log($scope.list);
            $scope.totalamount = 0
            for (var i = 0; i < $scope.list.length; i++) {
                $scope.totalamount = $scope.totalamount + $scope.list[i].amount;
            }
            
            
            
            
        }).error(function (response) {
            console.log("errorr", response);
            
            if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            
        })
        ngDialog.closeAll();
    }
    $scope.getBiddingItem();
    ///=========================================Delete Msg Popup Items=============================///////   
    $scope.deleteMsgPopupItems = function (currentId) {
            $scope.deleteCurrentItemId = currentId;
            $scope.DeleteConfirmMsg = "Are you sure to delete this item?";
            ngDialog.open({
                template: 'deleteitemMsg'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        ///=========================================DeleteItems Add Items=============================///////   
    $scope.deleteItems = function () {
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("itemId", $scope.deleteCurrentItemId);
            $http({
                url: MY_CONSTANT.url + '/bidding/deleteItems'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                if (response.statusCode == 200) {
                    $scope.getBiddingItem();
                }
            }).error(function (response) {
                console.log("errorr", response);
                
                if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            })
        }
        ///=========================================Edit Item Form Popup=============================///////   
    $scope.editItems = function (item) {
            $scope.currentEditFiled = item;
            console.log($scope.currentEditFiled);
            $scope.editform.itemName = $scope.currentEditFiled.itemName;
            $scope.editform.unit = $scope.currentEditFiled.unit;
            $scope.editform.unitPrice = $scope.currentEditFiled.unitPrice;
            $scope.editform.quantity = $scope.currentEditFiled.quantity;
            $scope.editform.description = $scope.currentEditFiled.itemDesc;
            //        $scope.editform.amount = $scope.currentEditFiled.amount;
            //        $scope.editform.tax = $scope.currentEditFiled.tax;
            $scope.editform.amount = $scope.currentEditFiled.amount;
            $scope.DeleteConfirmMsg = "Are you sure to delete this item?";
            ngDialog.open({
                template: 'editItemForm'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        ///=========================================DeleteItems Add Items=============================///////   
    $scope.saveEditItems = function (editform) {
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("itemId", $scope.currentEditFiled._id);
            fd.append("itemName", $scope.editform.itemName);
            fd.append("unit", $scope.editform.unit);
            fd.append("unitPrice", $scope.editform.unitPrice);
            fd.append("quantity", $scope.editform.quantity);
            fd.append("itemDesc", $scope.editform.description);
            //        fd.append("tax", $scope.editform.tax);
            //        $scope.editItemAmount = parseInt($scope.editform.unitPrice) * parseInt($scope.editform.quantity);
            fd.append("amount", $scope.editform.amount);
            $http({
                url: MY_CONSTANT.url + '/bidding/editItems'
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                if (response.statusCode == 200) {
                    $scope.getBiddingItem();
                }
            }).error(function (response) {
                console.log("errorr", response);
                
                if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            })
        }
    ///=========================================Submit Quote=============================/////// 
    $scope.submitQuote = function (quotetxt) {
            $scope.loading = true;
            var fd = new FormData();
            fd.append("projectId", $scope.projectId);
            fd.append("bidPrice", $scope.totalamount);
            fd.append("toC", $scope.quotetxt.toC);
            fd.append("note", $scope.quotetxt.note);
            $http({
                url: MY_CONSTANT.url + '/bidding/editQuoteByVideographer '
                , method: 'PUT'
                , headers: {
                    'Content-type': undefined
                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                }
                , data: fd
            }).success(function (response) {
                $scope.loading = false;
                if (response.statusCode == 200) {
                    ngDialog.closeAll();
                    $scope.SuccessQuoteMsg = "Quote Edit Successfully";
                    ngDialog.open({
                        template: 'submitQuote-success'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: false
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    $timeout(function(){
                         ngDialog.closeAll();
                         $state.go('app.newRequest');
                    },2000);

                }
            }).error(function (response) {
                $scope.loading = false;
                $scope.ErrorMsg = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                
                if (response.statusCode == 401) {
                $state.go('page.mainLanding');
            }
            })
        }
        //////////////////////=============================Additem POPUP=============================//////////////////////     
    $scope.submitQuoteSuccess = function () {
            ngDialog.closeAll();
            $state.go('app.newRequest');
        }
        //////////////////////=============================Additem POPUP=============================//////////////////////   
    $scope.additem = function () {
            $scope.afterClickButton = false;
            ngDialog.open({
                template: 'quote-Popup'
                , className: 'ngdialog-theme-default commandialog additem'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
    
    
    

    
    
    
    
    
    
    
    
    
});