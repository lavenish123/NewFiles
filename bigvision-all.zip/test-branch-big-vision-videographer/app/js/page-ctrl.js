App.controller('pageController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, $facebook, GooglePlus) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.forgot = {};
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
     $scope.afterClickButton = false;
     $scope.customerLink = CUSTOMER_URL;

  //if($cookieStore.get('obj') && $cookieStore.get('obj').accessToken !='' && $cookieStore.get('obj').accessToken != "undefined")
//     {
//         
//       if ($cookieStore.get('obj').isDetailsFilled == false) {
//       
//           $state.go('app.upload');
//       }
//       else if ($cookieStore.get('obj').isDetailsFilled == true) {
//         
//           $state.go('app.videographerDashboard');
//       }
//        
////        $state.go('app.upload');
//     }
//    

    //////////////////////=============================LOGIN POPUP=============================//////////////////////


    $scope.loginpopup = function () {
        console.log('loginpopup');
        $scope.loginSignFlag = 1;
        $scope.account = {};
        $scope.closeDialog();
        ngDialog.open({
            template: 'videographer-login',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================LOGIN FUNCTION=============================//////////////////////

    $scope.login = function (data) {

        $scope.afterClickButton = true;
        var fd = new FormData();
        fd.append('email', data.email);
        fd.append('password', data.password);
        fd.append('role', 'videographer');
        fd.append('deviceType', 'WEB');
        $scope.loading = true;
        $http({
                url: MY_CONSTANT.url + '/user/login',
                method: 'POST',
                headers: {
                    'Content-type': undefined
                },
                data: fd,
                transformRequest: angular.identity
            }).success(function (response) {
                 $scope.afterClickButton = false;
                $scope.loading = false;
             
                if (response.statusCode == 200) {
                    // var obj={'accessToken': response.data.token,'userRole':response.data.user.role,
                    // 'status':response.data.user.isActive,'name':response.data.user.name,
                    // 'profilePictureURL':response.data.user.profilePictureURL};
                    // console.log("login cookies",obj); 
                    // $cookieStore.put('obj',obj);

                    
                    localStorage.removeItem("CurrentAccess");
                    
                     var obj = {
                        'accessToken': response.data.token,
                         'isDetailsFilled': response.data.user.isDetailsFilled
                    };
                    $cookieStore.put('obj', obj);
                    
                 
                    localStorage.setItem("CurrentAccess", obj.accessToken);
                    
                    var profileDetails = {
                        'name': response.data.user.name,
                        'id':response.data.user._id,
                        'role':response.data.user.role,
                        'email': response.data.user.email,
                        'profilePictureURL': response.data.user.profilePictureURL
                    };
                    $cookieStore.put("profileDetails", profileDetails);
                    if (response.data.user.isEmailVerified == true) {
                        
                        if (response.data.user.isDetailsFilled == false) {
                            $scope.closeDialog();
                            $state.go('app.upload');
                        } else if (response.data.user.isDetailsFilled == true) {
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                            
                        }
                    } else {
                        $scope.otpAfterLogin();
                    }
                }
            })
            .error(function (response) {
                $scope.loading = false;
                 $scope.afterClickButton = false;
                $scope.loginerrormessage = response.message;
       
                ngDialog.open({
                    template: 'loginerror',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });

            })
    }

    
       


    //////////////////////=============================SIGNUP POPUP=============================//////////////////////

    $scope.signuppopup = function (data) {
        $scope.closeDialog();
        $scope.account = {};
        $scope.type = data;
        if (data == 'viaLoginPopUp') {
            ngDialog.open({
                template: 'videographer-signup2',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        } else {
            $scope.loginSignFlag = 2;
            ngDialog.open({
                template: 'videographer-signup',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
    }

    //////////////////////=============================RESEND OTP=============================//////////////////////

    $scope.resendOTP = function () {
//        var token = '';
//        if (typeof ($cookieStore.get('obj')) != undefined) {
//            if ($cookieStore.get('obj').accessToken == '' || $cookieStore.get('obj').accessToken == undefined) {
//                token = $scope.otpvar;
//            } else {
//
//                token = $cookieStore.get('obj').accessToken;
//            }
//        } else {
//            token = $scope.otpvar;
//        }

        $http({
                url: MY_CONSTANT.url + '/user/resendOTP',
                method: 'PUT',
                headers: {
                    authorization: 'bearer ' +  $scope.otpvar //$cookieStore.get('obj').accessToken
                }
            })
            .success(function (response) {

                if (response.statusCode == 200) {
                    $scope.message = 'OTP Sent Successfully';
                    ngDialog.open({ //Videographer login ngDialog
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });
                }


            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });

            })

    }


    //////////////////////=============================OTP POPUP=============================//////////////////////

    $scope.otp = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'otp-verify',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================OTP AFTER LOGIN POPUP=============================//////////////////////

    $scope.otpAfterLogin = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'otp-verify1',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================OTP VERIFY FUNCTION===========================//////////////////////

    $scope.otpVerify = function (data) {
        console.log("otp verifyyy");
        if (data.length < 6 || data.length > 6) {
            $scope.message = 'OTP Length must be 6 characters long';
            ngDialog.open({
                template: 'error',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
            // return;
        } else {
            var sendData = {
                "otpCode": data
            };
            $http({
                    url: MY_CONSTANT.url + '/user/verifyOTP',
                    method: 'PUT',
                    headers: {
                        'Content-type': undefined,
                        authorization: 'bearer ' + $scope.otpvar
                    },
                    data: JSON.stringify(sendData),
                    transformRequest: angular.identity
                })
                .success(function (response) {
                    $cookieStore.put("otpInfo", response);
                    if (response.statusCode == 200) {
                        // var obj={'accessToken': response.data.token,'userRole':response.data.user.role,'status':response.data.user.isActive,'name':response.data.user.name,'profilePictureURL':response.data.user.profilePictureURL};
                        // $cookieStore.put('obj',obj);
                        var obj = {
                            'accessToken': response.data.token
                        };
                        $cookieStore.put('obj', obj);
                        var profileDetails = {
                            'name': response.data.user.name,
                            'email': response.data.user.email,
                            'profilePictureURL': response.data.user.profilePictureURL
                        };
                        $cookieStore.put("profileDetails", profileDetails);
                        ngDialog.close();
                        $scope.otpsuccessmessage = 'OTP Verified successfully';
                        ngDialog.open({
                            template: 'otpsuccess',
                            className: 'ngdialog-theme-default commandialog',
                            showClose: false,
                            closeByDocument: false,
                            closeByEscape: false,
                            scope: $scope
                        });

                        $timeout(function(){
                            ngDialog.close();
                            $state.go('app.upload');
                        },2000);

                        // $state.go('app.upload');
                    }
                })
                .error(function (response) {

                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });

                })
        }
    }

    //////////////////////=============================Click Ok Function=============================//////////////////////

    $scope.okClick = function () {
        ngDialog.close();
        $state.go('app.upload');

    }

    //////////////////////=============================OTP VERIFY FUNCTION============================//////////////////////
    $scope.otpVerify1 = function (data) {
        console.log("otp verifyyy1111");
        if (data.length < 6 || data.length > 6) {
            $scope.message = 'OTP Length must be 6 characters long';
            ngDialog.open({ //Videographer login ngDialog
                template: 'error',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
            return;
        } else {
            var sendData = {
                "otpCode": data
            };
            $http({
                    url: MY_CONSTANT.url + '/user/verifyOTP',
                    method: 'PUT',
                    headers: {
                        'Content-type': undefined,
                        authorization: 'bearer ' + $cookieStore.get('obj').accessToken
                    },
                    data: JSON.stringify(sendData)
                })
                .success(function (response) {
                    if (response.statusCode == 200) {
                        var obj = {
                            'accessToken': response.data.token,
                            'userRole': response.data.user.role,
                            'status': response.data.user.isActive,
                            'name': response.data.user.name,
                            'profilePictureURL': response.data.user.profilePictureURL
                        };
                        $cookieStore.put('obj', obj);
                        $scope.closeDialog();
                        $scope.message = 'OTP Verified successfully.';
                        ngDialog.open({ //Videographer login ngDialog
                            template: 'error',
                            className: 'ngdialog-theme-default commandialog',
                            showClose: false,
                            closeByDocument: false,
                            closeByEscape: false,
                            scope: $scope
                        });
                         $timeout(function(){
                            ngDialog.close();
                            $state.go('app.upload');
                        },2000);
                        // $state.go('app.upload');
                    }

                })
                .error(function (response) {

                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login ngDialog
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });

                })
        }
    }


    $scope.closeDialog = function () {
        ngDialog.closeAll();
     
        
    }

    //////////////////////=============================SIGNUP =============================//////////////////////

    $scope.signUp = function (data) {
        if (data.password === data.passwordVerify) {

            $scope.afterClickButton = true;

            /* var url = "/customer/register";
            if($scope.type == "videographer")
            {
            url = "/videographer/register";
 
            }else if($scope.type == "customer"){
            url = "/customer/register";
 
            }
            if($scope.account.type && $scope.account.type!=""){
            url = $scope.account.type=="customer"?"/customer/register":"/videographer/register";
 
            }*/
            var fd = new FormData();
            fd.append("email", $scope.account.email);
            fd.append("name", $scope.account.name);
            fd.append("password", $scope.account.password);
            fd.append("deviceToken", "webtoken");
            fd.append("deviceType", "WEB");
            $http({
                    url: MY_CONSTANT.url + '/videographer/register',
                    method: 'POST',
                    headers: {
                        'Content-type': undefined
                    },
                    data: fd

                }).success(function (response) {
               $scope.afterClickButton = false;
                    // $cookieStore.put("otpInfo", response);
                    if (response.statusCode == 200) {
                        $scope.otpvar = response.data.token;
                        $scope.otp();
                    }
                })
                .error(function (response) {

                    $scope.signupmessage = response.message;
               $scope.afterClickButton = false;
                    ngDialog.open({
                        template: 'signuperror',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });

                })
        } else {
            $scope.message = 'Password did not matched';
            ngDialog.open({
                template: 'error',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }
    }

    //////////////////////=============================FORGOT PASSWORD POPUP =============================//////////////////////

    $scope.forgotPasswordPopup = function () {
        $scope.closeDialog();
        $scope.forgot = {};
        ngDialog.open({
            template: 'forgot-password',
            className: 'ngdialog-theme-default commandialog',
            showClose: false,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================FORGOT PASSWORD FUNCTION =============================//////////////////////

    $scope.submitForgotForm = function (data) {
        
         $scope.afterClickButton = true;
        
        $http({
            method: 'GET',
            url: MY_CONSTANT.url + '/user/forgotpassword?email=' + $scope.forgot.email + '&role=videographer'


        }).success(function (response) {

            $scope.resetmsg = "For reset password please check your email address.";
            ngDialog.close();
            ngDialog.open({
                template: 'error1',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });

        }).error(function (response) {
            $scope.message = response.message;
            
             $scope.afterClickButton = false;
            ngDialog.close();
            ngDialog.open({
                template: 'error',
                className: 'ngdialog-theme-default commandialog',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        })
    }

    //////////////////////=============================Reset Password Function=============================//////////////////////
    $scope.recover = function () {
        $scope.token = $location.search().passwordResetToken;
        $http({
            method: 'PUT',
            url: MY_CONSTANT.url + '/user/resetPassword?passwordResetToken=' + $scope.token + '&newPassword=' + $scope.account.password + '',

        }).success(function (response) {

            if (response.statusCode == 200) {
                $scope.successMsg = response.message;
                $state.go('page.mainLanding');
            }
        }).error(function (response) {

            $scope.errorMsg = response.message;

        })
    }


    /*==========================================================
     ==================Facebook login Final====================
     =========================================================== */
    function statusChangeCallback(response) {
        console.log('statusChangeCallback');
        console.log(response);
        // The response object is returned with a status field that lets the
        // app know the current login status of the person.
        // Full docs on the response object can be found in the documentation
        // for FB.getLoginStatus().
        if (response.status === 'connected') {
            console.log('connected');
            // Logged into your app and Facebook.
            testAPI(response);
        } else if (response.status == 'unknown') {
            FB.login(function (response) {
                console.log(response);
                FB.api('/me', function (response) {
                    console.log('Good to see you, ' + response.name + '.');
                    testAPI(response);
                });

            }, {
                scope: 'public_profile,email'
            });
        } else {
            console.log("not connected");
            FB.login(function (response) {
                if (response.authResponse) {
                    FB.api('/me', function (response) {
                        console.log('Good to see you, ' + response.name + '.');
                        testAPI(response);
                    });
                } else {
                    console.log('User cancelled login or did not fully authorize.');
                }
            });
        }
    }

    // This function is called when someone finishes with the Login
    // Button. See the onlogin handler attached to it in the sample
    // code below.
    $scope.checkLoginState = function () {
        console.log("fb loginn");
        $facebook.login().then(function () {
            console.log('fb login 1');
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                testAPILogin(response);
            });
        });
    }
    $scope.checkSignupState = function () {
        console.log("fb signnnnnup");
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                $facebook.logout();
                testAPISignup(response);
            });
        });
    }

    // Here we run a very simple test of the Graph API after login is
    // successful. See statusChangeCallback() for when this call is made.
    function testAPILogin(response) {
         console.log("facebook response login",response);
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        fd.append("role", 'videographer');
        var profileDetails = {
            'name': response.name,
            'email': response.email,
            'profilePictureURL': response.picture.data.url
        };
        $http({
                url: MY_CONSTANT.url + '/user/login',
                method: 'POST',
                headers: {
                    'Content-type': undefined
                },
                data: fd
            })
            .success(function (response) {
                console.log("signin via facebook response", response);
                // if (response.statusCode == 200) {
                // $cookieStore.put("obj", { 'accessToken': response.data.token, 'user': response.data.customer, 'userRole': response.data.user.customer, 'name': response.data.user.customer, 'status': response.data.user.isActive });

                // if (response.data.user.isEmailVerified == true) {
                // $scope.closeDialog();
                // $state.go('app.customerDash'); 
                // }
                // else {
                // $scope.otpAfterLogin();
                // }
                // }
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", {
                        'accessToken': response.data.token
                    });

                    if (response.data.user.email && response.data.user.email != '') {
                        profileDetails.email = response.data.user.email;
                    }
                    if (response.data.user.name && response.data.user.name != '') {
                        profileDetails.name = response.data.user.name;
                    }
                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    // if (response.data.user.isEmailVerified == true) {
                    //     if (response.data.user.isDetailsFilled == false) {
                    //         console.log("details filled false");
                    //         $scope.closeDialog();
                    //         $state.go('app.upload');
                    //     } else if (response.data.user.isDetailsFilled == true) {
                    //         console.log("details filled true");
                    //         $scope.closeDialog();
                    //         $state.go('app.videographerDashboard');
                    //     }
                    // } else {
                    //     $scope.otpAfterLogin();
                    // }
                        if (response.data.user.isDetailsFilled == false) {
                            console.log("details filled false");
                            $scope.closeDialog();
                            $state.go('app.upload');
                        } else if (response.data.user.isDetailsFilled == true) {
                            console.log("details filled true");
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }
                }
            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });

            })
    }
    /*==============================================================
    ====================Facebook login ends Final============================
    =========================================================== */

    /*==========================================================
    ==================Facebook signup Final====================
    =========================================================== */

    function testAPISignup(response) {
        console.log("facebook response signup",response);
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        var profileDetails = {
            'name': response.name,
            'email': response.email,
            'profilePictureURL': response.picture.data.url
        };
        $http({
                url: MY_CONSTANT.url + '/videographer/register',
                method: 'POST',
                headers: {
                    'Content-type': undefined
                },
                data: fd
            })
            .success(function (response) {
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", {
                        'accessToken': response.data.token
                    });
                    if (response.data.videographer.email && response.data.videographer.email != '') {
                        profileDetails.email = response.data.videographer.email;
                    }
                    if (response.data.videographer.name && response.data.videographer.name != '') {
                        profileDetails.name = response.data.videographer.name;
                    }
                    if (response.data.videographer.profilePictureURL && response.data.videographer.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.videographer.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    // if (response.data.videographer.isEmailVerified == true) {
                    //     if (response.data.videographer.isDetailsFilled == false) {
                    //         console.log("details filled false");
                    //         $scope.closeDialog();
                    //         $state.go('app.upload');
                    //     } else if (response.data.videographer.isDetailsFilled == true) {
                    //         console.log("details filled true");
                    //         $scope.closeDialog();
                    //         $state.go('app.videographerDashboard');
                    //     }

                    // } else {
                    //     $scope.otpAfterLogin();
                    // }
                    if (response.data.user.isDetailsFilled == false) {
                        console.log("details filled false");
                        $scope.closeDialog();
                        $state.go('app.upload');
                    } else if (response.data.user.isDetailsFilled == true) {
                        console.log("details filled true");
                        $scope.closeDialog();
                        $state.go('app.videographerDashboard');
                    }
                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({ //Videographer login ngDialog
                    template: 'error',
                    className: 'ngdialog-theme-default commandialog',
                    showClose: true,
                    closeByDocument: false,
                    closeByEscape: false,
                    scope: $scope
                });
            })
    }

    /*==============================================================
    ====================Facebook signup ends Final============================
    =========================================================== */


    //====================Linkdin login and Signup Final============================
    $scope.$on('event:social-sign-in-success', function (event, data) {
        if ($scope.loginSignFlag == 1) {
            var fd = new FormData();
            fd.append("email", data.email);
            fd.append("socialId", data.uid);
            fd.append("deviceType", "WEB");
            fd.append("socialStatus", true);
            fd.append("role", 'videographer');
            var profileDetails = {
                'name': data.name,
                'email': data.email,
                'profilePictureURL': data.imageUrl
            };
            $http({
                    url: MY_CONSTANT.url + '/user/login',
                    method: 'POST',
                    headers: {
                        'Content-type': undefined
                    },
                    data: fd
                })
                .success(function (response) {
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", {
                            'accessToken': response.data.token
                        });

                        if (response.data.user.email && response.data.user.email != '') {
                            profileDetails.email = response.data.user.email;
                        }
                        if (response.data.user.name && response.data.user.name != '') {
                            profileDetails.name = response.data.user.name;
                        }
                        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '' && response.data.user.profilePictureURL != ' ') {
                            profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                        }
                        $cookieStore.put("profileDetails", profileDetails);
                        if (response.data.user.isDetailsFilled == false) {
                            console.log("details filled false");
                            $scope.closeDialog();
                            $state.go('app.upload');
                       } else if (response.data.user.isDetailsFilled == true) {
                            console.log("details filled true");
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }
                        // if (response.data.user.isEmailVerified == true) {
                        //     if (response.data.user.isDetailsFilled == false) {
                        //         $scope.closeDialog();
                        //         $state.go('app.upload');
                        //     } else if (response.data.user.isDetailsFilled == true) {
                        //         $scope.closeDialog();
                        //         $state.go('app.videographerDashboard');
                        //     }
                        // } else {
                        //     $scope.otpAfterLogin();
                        // }
                    }
                })
                .error(function (response) {

                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login ngDialog
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });

                })
        } else if ($scope.loginSignFlag == 2) {
            var fd = new FormData();
            fd.append("email", data.email);
            fd.append("socialId", data.uid);
            fd.append("deviceType", "WEB");
            fd.append("socialStatus", true);
            var profileDetails = {
                'name': data.name,
                'email': data.email,
                'profilePictureURL': data.imageUrl
            };
            $http({
                    url: MY_CONSTANT.url + '/videographer/register',
                    method: 'POST',
                    headers: {
                        'Content-type': undefined
                    },
                    data: fd
                })
                .success(function (response) {
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", {
                            'accessToken': response.data.token
                        });
                        if (response.data.videographer.email && response.data.videographer.email != '') {
                            profileDetails.email = response.data.videographer.email;
                        }
                        if (response.data.videographer.name && response.data.videographer.name != '') {
                            profileDetails.name = response.data.videographer.name;
                        }
                        if (response.data.videographer.profilePictureURL && response.data.videographer.profilePictureURL != '' && response.data.videographer.profilePictureURL != ' ') {
                            profileDetails.profilePictureURL = response.data.videographer.profilePictureURL;
                        }
                        $cookieStore.put("profileDetails", profileDetails);
                        // if (response.data.videographer.isEmailVerified == true) {
                        //     if (response.data.videographer.isDetailsFilled == false) {
                        //         $scope.closeDialog();
                        //         $state.go('app.upload');
                        //     } else if (response.data.videographer.isDetailsFilled == true) {
                        //         $scope.closeDialog();
                        //         $state.go('app.videographerDashboard');
                        //     }

                        // } else {
                        //     $scope.otpAfterLogin();
                        // }
                         if (response.data.user.isDetailsFilled == false) {
                            console.log("details filled false");
                            $scope.closeDialog();
                            $state.go('app.upload');
                       } else if (response.data.user.isDetailsFilled == true) {
                            console.log("details filled true");
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }

                    }
                })
                .error(function (response) {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login ngDialog
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                    });

                })
        }
    });

    /*==============================================================
    ====================Google login start final================
    =========================================================== */
    $scope.GoogleLogin = function () {
        GooglePlus.login().then(function (authResult) {
            GooglePlus.getUser().then(function (user) {
                if ($scope.loginSignFlag == 1) {
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    fd.append("role", 'videographer');
                    var profileDetails = {
                        'name': user.name,
                        'email': user.email,
                        'profilePictureURL': user.picture
                    };
                    $http({
                            url: MY_CONSTANT.url + '/user/login',
                            method: 'POST',
                            headers: {
                                'Content-type': undefined
                            },
                            data: fd
                        })
                        .success(function (response) {
                            if (response.statusCode == 200) {
                                $cookieStore.put("obj", {
                                    'accessToken': response.data.token
                                });

                                if (response.data.user.email && response.data.user.email != '') {
                                    profileDetails.email = response.data.user.email;
                                }
                                if (response.data.user.name && response.data.user.name != '') {
                                    profileDetails.name = response.data.user.name;
                                }
                                if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '' && response.data.user.profilePictureURL != ' ') {
                                    profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                                }
                                $cookieStore.put("profileDetails", profileDetails);
                                // if (response.data.user.isEmailVerified == true) {
                                //     if (response.data.user.isDetailsFilled == false) {
                                //         $scope.closeDialog();
                                //         $state.go('app.upload');
                                //     } else if (response.data.user.isDetailsFilled == true) {
                                //         $scope.closeDialog();
                                //         $state.go('app.videographerDashboard');
                                //     }
                                // } else {
                                //     $scope.otpAfterLogin();
                                // }
                             if (response.data.user.isDetailsFilled == false) {
                                    console.log("details filled false");
                                    $scope.closeDialog();
                                    $state.go('app.upload');
                              } else if (response.data.user.isDetailsFilled == true) {
                                    console.log("details filled true");
                                    $scope.closeDialog();
                                    $state.go('app.videographerDashboard');
                                 }
                            }
                        })
                        .error(function (response) {

                            $scope.message = response.message;
                            ngDialog.open({ //Videographer login ngDialog
                                template: 'error',
                                className: 'ngdialog-theme-default commandialog',
                                showClose: true,
                                closeByDocument: false,
                                closeByEscape: false,
                                scope: $scope
                            });

                        })
                } else if ($scope.loginSignFlag == 2) {
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    // fd.append("name", user.name);
                    // fd.append("profilePictureURL", user.picture);
                    var profileDetails = {
                        'name': user.name,
                        'email': user.email,
                        'profilePictureURL': user.picture
                    };
                    $http({
                            url: MY_CONSTANT.url + '/videographer/register',
                            method: 'POST',
                            headers: {
                                'Content-type': undefined
                            },
                            data: fd
                        })
                        .success(function (response) {
                            if (response.statusCode == 200) {
                                $cookieStore.put("obj", {
                                    'accessToken': response.data.token
                                });
                                if (response.data.videographer.email && response.data.videographer.email != '') {
                                    profileDetails.email = response.data.videographer.email;
                                }
                                if (response.data.videographer.name && response.data.videographer.name != '') {
                                    profileDetails.name = response.data.videographer.name;
                                }
                                if (response.data.videographer.profilePictureURL && response.data.videographer.profilePictureURL != '' && response.data.videographer.profilePictureURL != ' ') {
                                    profileDetails.profilePictureURL = response.data.videographer.profilePictureURL;
                                }
                                $cookieStore.put("profileDetails", profileDetails);
                                // if (response.data.videographer.isEmailVerified == true) {
                                //     if (response.data.videographer.isDetailsFilled == false) {
                                //         $scope.closeDialog();
                                //         $state.go('app.upload');
                                //     } else if (response.data.videographer.isDetailsFilled == true) {
                                //         $scope.closeDialog();
                                //         $state.go('app.videographerDashboard');
                                //     }

                                // } else {
                                //     $scope.otpAfterLogin();
                                // }
                            if (response.data.user.isDetailsFilled == false) {
                                    console.log("details filled false");
                                    $scope.closeDialog();
                                    $state.go('app.upload');
                            } else if(response.data.user.isDetailsFilled == true) {
                                    console.log("details filled true");
                                    $scope.closeDialog();
                                    $state.go('app.videographerDashboard');
                        }
                            }
                        })
                        .error(function (response) {
                            $scope.message = response.message;
                            ngDialog.open({ //Videographer login ngDialog
                                template: 'error',
                                className: 'ngdialog-theme-default commandialog',
                                showClose: true,
                                closeByDocument: false,
                                closeByEscape: false,
                                scope: $scope
                            });

                        })
                }
            });

        }, function (err) {
            console.log(err);
        });
    };

    /*==============================================================
    ====================Google login end final================
    =========================================================== */
    
    
    
    
    
  
    
    
    
    
    
    
});