//===============loading directive========================
App.directive('loading', function () {
    return {
        restrict: 'E',
        replace:true,
        template: '<div class="loading"><img src="app/img/loading.gif"></div>',
        link: function (scope, element, attr) {
            scope.$watch('loading', function (val) {
                if (val)
                    $(element).show();
                else
                    $(element).hide();
            });
        }
    }
});

//===============password matching directive========================
App.directive('passwordMatching', PasswordMatching);
function PasswordMatching() {
        var directiveObj = {};
        directiveObj.restrict = 'A';
        directiveObj.require = 'ngModel';
        directiveObj.link = Link;
        function Link(scope,element,attr,ctrl) {
            function customeValidation(val){
                
                if(scope.registration.password === val){
                    ctrl.$setValidity('passwordMatching',true);
                }
                else{
                    ctrl.$setValidity('passwordMatching',false);
                }
                return val;
            }
            ctrl.$parsers.push(customeValidation);
        }
        return directiveObj;
    }

//===============password matching directive========================
App.directive('passwordMatchingg', PasswordMatchingg);
function PasswordMatchingg() {
    
        var directiveObj = {};
        directiveObj.restrict = 'A';
        directiveObj.require = 'ngModel';
        directiveObj.link = Link;
        function Link(scope,element,attr,ctrl) {
            function customeValidation(val){   
                if(scope.account.password === val){
                    ctrl.$setValidity('passwordMatchingg',true);
                }
                else{
                    ctrl.$setValidity('passwordMatchingg',false);
                }
                return val;
            }
            ctrl.$parsers.push(customeValidation);
        }
        return directiveObj;
    }
