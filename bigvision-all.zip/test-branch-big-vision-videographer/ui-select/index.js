require('./dist/select.js');
module.exports = 'ui.select';
