App.controller('PageHeaderController', function ($rootScope,$window, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, $facebook, GooglePlus,ApiService) {
    "use strict";
    $scope.location = {}
    $scope.registration = {};
    $scope.account = {};
    $scope.linkdinaccount = {};
    $scope.forgot = {};
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.videographerLink = VIDEOGRAPHER_URL;

    /////=============================Category auto search=============================///
    $scope.looking = undefined;
    $scope.states = [];
    $scope.category = function () {
        // $http({
        //     url: MY_CONSTANT.url + '/category/getAllCategories',
        //     method: 'GET'
        // })
           ApiService.apiCall('/category/getAllCategories','GET',0)
            .success(function (response) {
                if (response.statusCode == 200) {
                    $scope.list = response.data;
                    var i;
                    for (i = 0; i < $scope.list.length; i++) {
                        $scope.states.push($scope.list[i].categoryName);
                    }
                    $scope.onedit = function () {
                        $scope.states;
                    }
                }
            })
            .error(function (response) {  
                 if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                     ngDialog.open({
                        template: 'error',
                        className: 'ngdialog-theme-default commandialog',
                        showClose: true,
                        closeByDocument: false,
                        closeByEscape: false,
                        scope: $scope
                });
            }
        })
    }
    $scope.category();

    //////////////////////=============================LOGIN POPUP=============================//////////////////////
    $scope.loginpopup = function () {
        $scope.loginSignFlag = 1;
        $scope.closeDialog();
        $scope.account = {};
        ngDialog.open({
            template: 'customer-login',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================LOGIN FUNCTION=============================//////////////////////
    $scope.login = function (data) {
        var fd = new FormData();
        fd.append('email', data.email);
        fd.append('password', data.password);
        fd.append('deviceType', 'WEB');
        fd.append('role', 'customer');
        $scope.loading = true;
        // $http({
        //     url: MY_CONSTANT.url + '/user/login',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined
        //     },
        //     data: fd,
        //     transformRequest: angular.identity
        // })
        ApiService.apiCall('/user/login','POST',1,fd)
        .success(function (response) {
            $scope.loading = false;
            if (response.statusCode == 200) {



                var obj = { 'accessToken': response.data.token };
                $cookieStore.put('obj', obj);
                var profileDetails = {'id':response.data.user._id, 'name': response.data.user.name, 'email': response.data.user.email, 'profilePictureURL': response.data.user.profilePictureURL,'role': response.data.user.role};
                // $cookieStore.put("obj", { 'accessToken': response.data.token});
                $cookieStore.put("profileDetails", profileDetails);
                console.log("cookieess put", $cookieStore.put("profileDetails", profileDetails));
                if (response.data.user.isEmailVerified == true) {
                    if (response.data.user.role == 'customer') {
                        $scope.closeDialog();
                        $state.go('app.customerDash');
                    }
                    else {
                        if (response.data.user.isDetailsFilled == false) {
                            $scope.closeDialog();
                            $state.go('app.upload');
                        }
                        else if (response.data.user.isDetailsFilled == true) {
                            $scope.closeDialog();
                            $state.go('app.videographerDashboard');
                        }
                    }
                }
                else {

                    $scope.otpAfterLogin();
                }
            }


        })
            .error(function (response) {
                $scope.loading = false;
            //     if (response.statusCode == 401) {
            //         $cookieStore.remove('obj');
            //         $state.go('page.mainLanding');
            //     } else {
            //         $scope.message = response.message;
            //           ngDialog.open({
            //             template: 'error'
            //             , className: 'ngdialog-theme-default commandialog'
            //             , showClose: true
            //             , closeByDocument: false
            //             , closeByEscape: false
            //             , scope: $scope
            //     });
            // }
         
                    $scope.message = response.message;
                      ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                });
        })
    }



    //////////////////////=============================SIGNUP POPUP=============================//////////////////////

    $scope.signuppopup = function (data) {
        $scope.closeDialog();
        $scope.account = {};
        $scope.type = data;
        if (data == 'viaLoginPopUp') {
            ngDialog.open({
                template: 'videographer-signup2'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        else {
            $scope.loginSignFlag = 2;
            ngDialog.open({
                template: 'videographer-signup'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
    }

    //////////////////////=============================Choose Role POPUP=============================//////////////////////

    $scope.selectRolePopup = function () {
        ngDialog.open({
            template: 'select-role',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope

        })

    }

    //////////////////////=============================RESEND OTP=============================//////////////////////

    $scope.resendOTP = function () {
        $http({
            url: MY_CONSTANT.url + '/user/resendOTP',
            method: 'PUT',
            headers: {
                authorization: 'bearer ' + $scope.otpvar
            }
        })
            .success(function (response) {

                if (response.statusCode == 200) {
                    $scope.message = 'OTP Sent Successfully';
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
            .error(function (response) {
                 if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                });
            }
            })
    }

    //////////////////////=============================OTP POPUP=============================//////////////////////

    $scope.otp = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'otp-verify'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }

    //////////////////////=============================OTP AFTER LOGIN POPUP=============================//////////////////////

    $scope.otpAfterLogin = function () {
        $scope.closeDialog();
        ngDialog.open({
            template: 'otp-verify1'
            , className: 'ngdialog-theme-default commandialog'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false
            , scope: $scope
        });
    }

    //////////////////////=============================OTP VERIFY FUNCTION===========================//////////////////////
    $scope.nextBtnDisable=false;
    $scope.otpVerify = function (data) {
        console.log("otp verificationnnnnnnn");
         $scope.nextBtnDisable=true;
        if (data.length < 6 || data.length > 6) {
            $scope.message = 'OTP Length is not Valid';
            ngDialog.open({
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            // return;
        }
        else {
            var sendData = { "otpCode": data };
            $http({
                url: MY_CONSTANT.url + '/user/verifyOTP',
                method: 'PUT',
                headers: {
                    'Content-type': undefined,
                    authorization: 'bearer ' + $scope.otpvar
                },
                data: JSON.stringify(sendData),
                transformRequest: angular.identity
            })
                .success(function (response) {
                    $scope.nextBtnDisable=false;
                    $cookieStore.put("otpInfo", response);
                    if (response.statusCode == 200) {
                        var obj = { 'accessToken': response.data.token };
                        $cookieStore.put('obj', obj);
                        var profileDetails = { 'name': response.data.user[0].name, 'email': response.data.user[0].email, 'profilePictureURL': response.data.user[0].profilePictureURL };
                        $cookieStore.put("profileDetails", profileDetails);
                        console.log("profile details otp verify",$cookieStore.put("profileDetails", profileDetails));
                        ngDialog.close();
                                $scope.message2 = 'OTP Verified successfully';
                                ngDialog.open({
                                template: 'success-after-login'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: false
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });  
                         $timeout(function(){
                             $state.go('app.customerDash');
                         },2000);
                }
            })
                .error(function (response) {
                $scope.nextBtnDisable=false;
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                      ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                });
            }
        })
        }
    }

    //////////////////////=============================OTP VERIFY FUNCTION============================//////////////////////

    $scope.nextBtnDisable=false;
    $scope.otpVerify1 = function (data) {
         console.log("otp verificationnnnnnnn1111111111111111");
        $scope.nextBtnDisable=true;
        if (data.length < 6 || data.length > 6) {
            $scope.message = 'OTP Length is not Valid';
            ngDialog.open({ //Videographer login  ngDialog
                template: 'error'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            // return;
        }
        else {
            // var sendData = { "otpCode": data };
            var fd=new FormData();
            fd.append("otpCode",data);
            // $http({
            //     url: MY_CONSTANT.url + '/user/verifyOTP',
            //     method: 'PUT',
            //     headers: {
            //         'Content-type': undefined,
            //         authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            //     },
            //     data: JSON.stringify(sendData)
            // })
             ApiService.apiCall('/user/verifyOTP','PUT',3,fd)
                .success(function (response) {
                     $scope.nextBtnDisable=false;
                    if (response.statusCode == 200) {
                        // var obj = { 'accessToken': response.data.token, 'userRole': response.data.user.role, 'status': response.data.user.isActive, 'name': response.data.user.name, 'profilePictureURL': response.data.user.profilePictureURL };
                        // $cookieStore.put('obj', obj);
                        var profileDetails = { 'name': response.data.user[0].name, 'email': response.data.user[0].email, 'profilePictureURL': response.data.user[0].profilePictureURL };
                        $cookieStore.put("profileDetails otpverify1", profileDetails);
                        console.log("profile details otp verify",$cookieStore.put("profileDetails", profileDetails));
                        $scope.closeDialog();
                        $scope.message1 = 'OTP Verified successfully.';
                        ngDialog.open({ //Videographer login  ngDialog
                            template: 'success'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: false
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                        });
                        $timeout(function(){
                             $state.go('app.customerDash');
                         },2000);

                    }
                })
                .error(function (response) {
                     $scope.nextBtnDisable=false;
                    if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                    });
                }
            })
        }
    }


    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }

    $scope.okClick = function () {
        ngDialog.close();
        $state.go('app.customerDash')

    }

    //////////////////////=============================SIGNUP =============================//////////////////////

    $scope.submitBtnDisabled = false;
    $scope.signUp = function (data) {
        if (data.password === data.passwordVerify) {
            $scope.submitBtnDisabled = true;
            var fd = new FormData();
            fd.append("email", $scope.account.email);
            fd.append("name", $scope.account.name);
            fd.append("password", $scope.account.password);
            fd.append("deviceToken", "webtoken");
            fd.append("deviceType", "WEB");
            // $http({
            //     url: MY_CONSTANT.url + '/customer/register',
            //     method: 'POST',
            //     headers: {
            //         'Content-type': undefined
            //     },
            //     data: fd

            // })
            ApiService.apiCall('/customer/register','POST',1,fd)
            .success(function (response) {
                console.log("response of signup",response);
                if (response.statusCode == 200) {
                    //var profileDetails = {'email': response.data.customer.email};
                    //console.log("signup email", profileDetails.email);
                    // $cookieStore.put("obj", { 'accessToken': response.data.token});
                    //$cookieStore.put("profileDetails", profileDetails);            
                    $scope.otpvar = response.data.token;
                    $scope.submitBtnDisabled = false;
                    $scope.otp();
                }
            })
                .error(function (response) {
                    $scope.submitBtnDisabled = false;
                      if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                    });
                }

                })
        }
        else {
              if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message='Password did not matched';
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                    });
                }
        }
    }

    //////////////////////=============================FORGOT PASSWORD POPUP =============================//////////////////////

    $scope.forgotPasswordPopup = function () {
        $scope.closeDialog();
        $scope.forgot = {};
        ngDialog.open({
            template: 'forgot-password',
            className: 'ngdialog-theme-default commandialog',
            showClose: false,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

    //////////////////////=============================FORGOT PASSWORD FUNCTION =============================//////////////////////

    $scope.submitForgotForm = function (data) {
        // $http({
        //     method: 'GET',
        //     url: MY_CONSTANT.url + '/user/forgotpassword?email=' + $scope.forgot.email + '&role=customer'


        // })
        ApiService.apiCall('/user/forgotpassword?email=' + $scope.forgot.email + '&role=customer','GET',0)
        .success(function (response) {
            $scope.resetmsg = "For reset password please check your email address.";
            ngDialog.close();
            ngDialog.open({
                template: 'error1'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });

        }).error(function (response) {
            ngDialog.close();
             if (response.statusCode == 401) {
                        $cookieStore.remove('obj');
                        $state.go('page.mainLanding');
                    } else {
                        $scope.message = response.message;
                        ngDialog.open({
                            template: 'error'
                            , className: 'ngdialog-theme-default commandialog'
                            , showClose: true
                            , closeByDocument: false
                            , closeByEscape: false
                            , scope: $scope
                    });
                }
        })
    }

    /*==========================================================
          ==================Facebook login Final====================
        ===========================================================    */
    function statusChangeCallback(response) {
        console.log('statusChangeCallback');
        console.log(response);
        if (response.status === 'connected') {
            console.log('connected');
            testAPI(response);
        }
        else if (response.status == 'unknown') {
            FB.login(function (response) {
                console.log(response);
                FB.api('/me', function (response) {
                    console.log('Good to see you, ' + response.name + '.');
                    testAPI(response);
                });

            }, { scope: 'public_profile,email' });
        }
        else {
            console.log("not connected");
            FB.login(function (response) {
                if (response.authResponse) {
                    FB.api('/me', function (response) {
                        console.log('Good to see you, ' + response.name + '.');
                        testAPI(response);
                    });
                } else {
                    console.log('User cancelled login or did not fully authorize.');
                }
            });
        }
    }

    $scope.checkLoginState = function () {
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                testAPILogin(response);
            });
        });
    }
    $scope.checkSignupState = function () {
        $facebook.login().then(function () {
            $facebook.api("/me?fields=id,name,email,picture").then(function (response) {
                console.log('fb res', response);
                $facebook.logout();
                testAPISignup(response);
            });
        });
    }

    function testAPILogin(response) {
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        fd.append("role", 'customer');
        var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
        // $http({
        //     url: MY_CONSTANT.url + '/user/login',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined
        //     },
        //     data: fd
        // })
            ApiService.apiCall('/user/login','POST',1,fd)
            .success(function (response) {
                console.log("signin via facebook response", response);
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", { 'accessToken': response.data.token });

                    if (response.data.user.email && response.data.user.email != '') {
                        profileDetails.email = response.data.user.email;
                    }
                    if (response.data.user.name && response.data.user.name != '') {
                        profileDetails.name = response.data.user.name;
                    }
                    if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    $scope.closeDialog();
                    $state.go('app.customerDash');
                    // if (response.data.user.isEmailVerified == true) {
                    //     $scope.closeDialog();
                    //     $state.go('app.customerDash');
                    // }
                    // else {
                    //     $scope.otpAfterLogin();
                    // }
                }
            })
            .error(function (response) {

                $scope.message = response.message;
                ngDialog.open({ //Videographer login  ngDialog
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });

            })
    }
    /*==============================================================
     ====================Facebook login ends Final============================
     ===========================================================    */

    /*==========================================================
       ==================Facebook signup Final====================
     ===========================================================    */

    function testAPISignup(response) {
        var url = '';
        if ($scope.type == 'customer') {
            url = '/user/login';
        }
        var fd = new FormData();
        fd.append("email", response.email);
        fd.append("socialId", response.id);
        fd.append("deviceType", "WEB");
        fd.append("socialStatus", true);
        var profileDetails = { 'name': response.name, 'email': response.email, 'profilePictureURL': response.picture.data.url };
        // $http({
        //     url: MY_CONSTANT.url + '/customer/register',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined
        //     },
        //     data: fd
        // })
          ApiService.apiCall('/customer/register','POST',1,fd)
            .success(function (response) {
                console.log("signin via facebook response", response);
                console.log("signin via google plus response", response);
                if (response.statusCode == 200) {
                    $cookieStore.put("obj", { 'accessToken': response.data.token });
                    if (response.data.customer.email && response.data.customer.email != '') {
                        profileDetails.email = response.data.customer.email;
                    }
                    if (response.data.customer.name && response.data.customer.name != '') {
                        profileDetails.name = response.data.customer.name;
                    }
                    if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                        profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                    }
                    console.log('profileDetails page', profileDetails);
                    $cookieStore.put("profileDetails", profileDetails);
                    $scope.closeDialog();
                    $state.go('app.customerDash');
                    // if (response.data.customer.isEmailVerified == true) {
                    //     $scope.closeDialog();
                    //     $state.go('app.customerDash');
                    // }
                    // else {
                    //     $scope.otpAfterLogin();
                    // }
                }
            })
            .error(function (response) {
                $scope.message = response.message;
                ngDialog.open({ //Videographer login  ngDialog
                    template: 'error'
                    , className: 'ngdialog-theme-default commandialog'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
            })
    }

    /*==============================================================
        ====================Facebook signup ends Final============================
        ===========================================================    */

    //====================Linkdin login and Signup Final============================
    $scope.$on('event:social-sign-in-success', function (event, data) {
        if ($scope.loginSignFlag == 1) {
            console.log("Hit Signin API");
            console.log("on data", data); // 'Data to send'
            var fd = new FormData();
            fd.append("email", data.email);
            fd.append("socialId", data.uid);
            fd.append("deviceType", "WEB");
            fd.append("socialStatus", true);
            fd.append("role", 'customer');
            var profileDetails = { 'name': data.name, 'email': data.email, 'profilePictureURL': data.imageUrl };
            // $http({
            //     url: MY_CONSTANT.url + '/user/login',
            //     method: 'POST',
            //     headers: {
            //         'Content-type': undefined
            //     },
            //     data: fd
            // })
              ApiService.apiCall('/user/login','POST',1,fd)
                .success(function (response) {
                    console.log("signin via linkdin response", response);
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", { 'accessToken': response.data.token });

                        if (response.data.user.email && response.data.user.email != '') {
                            profileDetails.email = response.data.user.email;
                        }
                        if (response.data.user.name && response.data.user.name != '') {
                            profileDetails.name = response.data.user.name;
                        }
                        if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                            profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                        }
                        console.log('profileDetails page', profileDetails);
                        $cookieStore.put("profileDetails", profileDetails);
                        $scope.closeDialog();
                        $state.go('app.customerDash');
                        // if (response.data.user.isEmailVerified == true) {
                        //     $scope.closeDialog();
                        //     $state.go('app.customerDash');
                        // }
                        // else {
                        //     $scope.otpAfterLogin();
                        // }
                    }
                })
                .error(function (response) {

                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });

                })
        }
        else if ($scope.loginSignFlag == 2) {
            console.log("Hit SignUp API");
            console.log("on data", data); // 'Data to send'
            var fd = new FormData();
            fd.append("email", data.email);
            fd.append("socialId", data.uid);
            fd.append("deviceType", "WEB");
            fd.append("socialStatus", true);
            var profileDetails = { 'name': data.name, 'email': data.email, 'profilePictureURL': data.imageUrl };
            // $http({
            //     url: MY_CONSTANT.url + '/customer/register',
            //     method: 'POST',
            //     headers: {
            //         'Content-type': undefined
            //     },
            //     data: fd
            // })
              ApiService.apiCall('/customer/register','POST',1,fd)
                .success(function (response) {
                    console.log("signin via linkdin response", response);
                    if (response.statusCode == 200) {
                        $cookieStore.put("obj", { 'accessToken': response.data.token });
                        if (response.data.customer.email && response.data.customer.email != '') {
                            profileDetails.email = response.data.customer.email;
                        }
                        if (response.data.customer.name && response.data.customer.name != '') {
                            profileDetails.name = response.data.customer.name;
                        }
                        if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                            profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                        }
                        console.log('profileDetails page', profileDetails);
                        $cookieStore.put("profileDetails", profileDetails);
                        $scope.closeDialog();
                        $state.go('app.customerDash');
                        // if (response.data.customer.isEmailVerified == true) {
                        //     $scope.closeDialog();
                        //     $state.go('app.customerDash');
                        // }
                        // else {
                        //     $scope.otpAfterLogin();
                        // }
                    }
                })
                .error(function (response) {
                    $scope.message = response.message;
                    ngDialog.open({ //Videographer login  ngDialog
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });

                })
        }
    });


    /*==============================================================
        ====================Google login start final================
        ===========================================================    */
    $scope.GoogleLogin = function () {
        GooglePlus.login().then(function (authResult) {
            console.log("authresult", authResult);
            GooglePlus.getUser().then(function (user) {
                console.log("user", user);
                if ($scope.loginSignFlag == 1) {
                    console.log("Hit Signin google plus API");
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    fd.append("role", 'customer');
                    var profileDetails = { 'name': user.name, 'email': user.email, 'profilePictureURL': user.picture };
                    // $http({
                    //     url: MY_CONSTANT.url + '/user/login',
                    //     method: 'POST',
                    //     headers: {
                    //         'Content-type': undefined
                    //     },
                    //     data: fd
                    // })
                     ApiService.apiCall('/user/login','POST',1,fd)
                        .success(function (response) {
                            console.log("signin via google plus response", response);
                            if (response.statusCode == 200) {
                                $cookieStore.put("obj", { 'accessToken': response.data.token });

                                if (response.data.user.email && response.data.user.email != '') {
                                    profileDetails.email = response.data.user.email;
                                }
                                if (response.data.user.name && response.data.user.name != '') {
                                    profileDetails.name = response.data.user.name;
                                }
                                if (response.data.user.profilePictureURL && response.data.user.profilePictureURL != '') {
                                    profileDetails.profilePictureURL = response.data.user.profilePictureURL;
                                }
                                console.log('profileDetails page', profileDetails);
                                $cookieStore.put("profileDetails", profileDetails);
                                 $scope.closeDialog();
                                 $state.go('app.customerDash');
                                // if (response.data.user.isEmailVerified == true) {
                                //     $scope.closeDialog();
                                //     $state.go('app.customerDash');
                                // }
                                // else {
                                //     $scope.otpAfterLogin();
                                // }
                            }
                        })
                        .error(function (response) {

                            $scope.message = response.message;
                            ngDialog.open({ //Videographer login  ngDialog
                                template: 'error'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });

                        })
                }
                else if ($scope.loginSignFlag == 2) {
                    console.log("Hit SignUp google plus API");
                    var fd = new FormData();
                    fd.append("email", user.email);
                    fd.append("socialId", user.id);
                    fd.append("deviceType", "WEB");
                    fd.append("socialStatus", true);
                    //        fd.append("name", user.name);
                    //        fd.append("profilePictureURL", user.picture);

                    var profileDetails = { 'name': user.name, 'email': user.email, 'profilePictureURL': user.picture };
                    // $http({
                    //     url: MY_CONSTANT.url + '/customer/register',
                    //     method: 'POST',
                    //     headers: {
                    //         'Content-type': undefined
                    //     },
                    //     data: fd
                    // })
                     ApiService.apiCall('/customer/register','POST',1,fd)
                        .success(function (response) {
                            console.log("signin via google plus response", response);
                            if (response.statusCode == 200) {
                                $cookieStore.put("obj", { 'accessToken': response.data.token });
                                if (response.data.customer.email && response.data.customer.email != '') {
                                    profileDetails.email = response.data.customer.email;
                                }
                                if (response.data.customer.name && response.data.customer.name != '') {
                                    profileDetails.name = response.data.customer.name;
                                }
                                if (response.data.customer.profilePictureURL && response.data.customer.profilePictureURL != '') {
                                    profileDetails.profilePictureURL = response.data.customer.profilePictureURL;
                                }
                                console.log('profileDetails page', profileDetails);
                                $cookieStore.put("profileDetails", profileDetails);
                                $scope.closeDialog();
                                $state.go('app.customerDash');
                                // if (response.data.customer.isEmailVerified == true) {
                                //     $scope.closeDialog();
                                //     $state.go('app.customerDash');
                                // }
                                // else {
                                //     $scope.otpAfterLogin();
                                // }
                            }
                        })
                        .error(function (response) {
                            $scope.message = response.message;
                            ngDialog.open({ //Videographer login  ngDialog
                                template: 'error'
                                , className: 'ngdialog-theme-default commandialog'
                                , showClose: true
                                , closeByDocument: false
                                , closeByEscape: false
                                , scope: $scope
                            });

                        })
                }
            });

        }, function (err) {
        });
    };

    /*==============================================================
           ====================Google login end final================
       ===========================================================    */
});





