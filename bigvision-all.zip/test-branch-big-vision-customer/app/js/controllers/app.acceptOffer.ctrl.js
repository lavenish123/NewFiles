/**
 * Created by admin-in on 27/4/17.
 */
App.controller('AcceptOfferController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
    $scope.selectProjectId = $stateParams.id;
    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    $scope.getVideographerImgSrc = {};
    console.log($scope.proTitle);
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        console.log("small" + $scope.projectTime);
    }
    ////////////////////=============================Get  My Quotes=============================//////////////////////
    $scope.getQuotesVideographerList = function () {
        ApiService.apiCall('/bidding/getQuotesForProject?projectId=' + $scope.selectProjectId, 'GET', 2).success(function (response) {
           console.log("response getQuotesVideographerList - ", response.data.quotes);
            
//            $scope.getVideographerImgSrc = response.data.quotes[0].videographerId.profilePictureURL;
//            
//            
//             console.log("response getQuotesVideographer img - ",  $scope.getVideographerImgSrc);
            
            $scope.QuotesVideographerList = response.data.quotes;
            
            
//for (var i = 0; i <  response.data.quotes.length; i++) { 
//    
//if(response.data.quotes[i].videographerId.profilePictureURL == 'undefined'){
//    
//    response.data.quotes[i].videographerId.profilePictureURL
//    
//}
//    
//}
            
            
            
        }).error(function (response) {
            console.log(response);
        });
        ngDialog.closeAll();
    }
    $scope.getQuotesVideographerList();
    console.log("selectProjectId " + $scope.selectProjectId);
    ///=========================================Delete Msg Popup Items=============================///////   
    $scope.deleteMsgPopupItems = function (currentId) {
            $scope.deleteCurrentItemId = currentId;
            $scope.DeleteConfirmMsg = "Are you sure to delete this item?";
            ngDialog.open({
                template: 'deleteitemMsg'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        ////////////////////=============================Remove Quote ByCustomer=============================//////////////////////
    $scope.removeQuoteByCustome = function () {
        var fd = new FormData();
        fd.append("projectId", $scope.selectProjectId);
        fd.append("videographerId", $scope.deleteCurrentItemId);
        ApiService.apiCall('/bidding/removeQuoteByCustomer', 'PUT', 3, fd).success(function (response) {
            if (response.statusCode == 200) {
                $scope.getQuotesVideographerList();
            }
            //            console.log(response.data.quotes);
            //            $scope.QuotesVideographerList = response.data.quotes
        }).error(function (response) {
            console.log(response);
        });
    }
    console.log($scope.selectProjectId);
    /////=========================================DeleteItems Add Items=============================///////   
    //    $scope.deleteItems = function () {
    //            var fd = new FormData();
    //            fd.append("projectId", $scope.projectId);
    //            fd.append("itemId", $scope.deleteCurrentItemId);
    //            $http({
    //                url: MY_CONSTANT.url + '/bidding/deleteItems'
    //                , method: 'PUT'
    //                , headers: {
    //                    'Content-type': undefined
    //                    , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
    //                }
    //                , data: fd
    //            }).success(function (response) {
    //                if (response.statusCode == 200) {
    //                    $scope.getBiddingItem();
    //                }
    //            }).error(function (response) {
    //                console.log("errorr", response);
    //                
    //                if (response.statusCode == 401) {
    //                $state.go('page.mainLanding');
    //            }
    //            })
    //        }
    //    
    //    
    //    
    //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
})