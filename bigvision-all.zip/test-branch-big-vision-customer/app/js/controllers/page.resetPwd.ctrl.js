App.controller('ResetPwdController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, $facebook, GooglePlus, ApiService) {

    //////////////////////=============================Reset Password Function=============================//////////////////////

    $scope.account = {};
    $scope.token = $location.search().passwordResetToken;

    $scope.recover = function() {
        ApiService.apiCall('/user/resetPassword?passwordResetToken=' + $scope.token + '&newPassword=' + $scope.account.password + '', 'PUT', 0)
            .success(function (response) {

                if (response.statusCode == 200) {
                    $scope.successMsg = response.message;
                    $state.go('page.mainLanding');
                }
            }).error(function (response) {
                if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.errorMsg = response.message;
                    // ngDialog.open({
                    //     template: 'error'
                    //     , className: 'ngdialog-theme-default commandialog'
                    //     , showClose: true
                    //     , closeByDocument: false
                    //     , closeByEscape: false
                    //     , scope: $scope
                    // });
                }
            })
    }
}); 