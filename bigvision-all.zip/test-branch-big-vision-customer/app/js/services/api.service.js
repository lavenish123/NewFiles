App.factory('ApiService', ApiService);

function ApiService($http, $q, $cookieStore, MY_CONSTANT) {
    var serviceObj = {};
    serviceObj.apiCall = ApiCall;

    function ApiCall(url, method, serviceType, data) {
        var httpObj = {
            method: method,
            url: MY_CONSTANT.url + url,
            headers: {
                'Content-Type': undefined,
                // 'Access-Control-Allow-Origin':'*'
            },
            transformRequest: angular.identity
        };
        switch (serviceType) {
            case 0: // no authorization and no  data in api
                break;
            case 1: // no authorization and  data in api
                httpObj.data = data;
                break;
            case 2: // authorization and no data in api
                httpObj.headers['authorization'] = "bearer " + $cookieStore.get('obj').accessToken;
                break;
            case 3: // authorization and  data in api
                httpObj.headers['authorization'] = "bearer " + $cookieStore.get('obj').accessToken;
                httpObj.data = data;
                break;
            default:
                break;
        }
        var http = $http(httpObj);
        return http;
    }
    return serviceObj;
}