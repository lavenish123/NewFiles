/**
 * Created by admin-in on 8/6/17.
 */
App.controller('commisionController', function ($scope,$state, $http, $cookies, $cookieStore,ngDialog,ApiService, MY_CONSTANT, $timeout) {

    'use strict';
    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = /^[a-zA-Z ]{2,30}$/;
    $scope.number = /^[0-9]*$/;
    $scope.loading = true;

    ApiService.apiCall('/admin/getDefaults', 'GET', 2)
   /* $http({
        url: MY_CONSTANT.url + '/adminDefaults/getDefaults',
        method: "GET",
        headers: {
            'authorization': 'bearer' + " " + $cookieStore.get('obj').accesstoken,
            'Content-type': undefined
        }
    })*/
        .success(function(data) {
            $scope.loading = false;
            if(data.statusCode == 200)
            {

                $scope.allData = data.data;
            }
        })
        .error(function (response) {
            console.log('ERROR', response.message);
            ngDialog.close();
            $scope.message = response.message;
            ngDialog.open({
                template: 'error'
                , className: 'dialog-container'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            // $state.reload();
        })


    $scope.edit = function(da){

        $scope.dataToEdit = da;

        ngDialog.openConfirm({
            template: 'editCommision',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })

    }

    $scope.editCommision = function(data)
    {
        var fd = new FormData();
        fd.append('commissionFlat',parseFloat(data.commissionFlat));
        fd.append('commissionPercentage',parseFloat(data.commissionPercentage));


        ApiService.apiCall('/admin/setDefaults', 'POST', 3,fd)
       .success(function(data) {
                $scope.loading = false;
                if(data.statusCode == 200)
                {

                    ngDialog.close();
                    $scope.message = data.message;
                    ngDialog.open({
                        template: 'success'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    //$state.reload();
                }
            })
            .error(function (response) {
                console.log('ERROR', response.message);
                ngDialog.close();
                $scope.message = response.message;
                ngDialog.open({
                    template: 'error'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                // $state.reload();
            })
    }


    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }



});