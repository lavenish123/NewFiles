// To run this code, edit file
// index.html or index.jade and change
// html data-ng-app attribute from
// angle to myAppName
// -----------------------------------

var App = angular.module('AppName', ['angle', 'ng-jwplayer' , 'uiGmapgoogle-maps', 'ckeditor', 'socialLogin', 'googleplus']);

App.config(['uiGmapGoogleMapApiProvider', function (GoogleMapApi) {
    GoogleMapApi.configure({
        //    key: 'your api key',
        v: '3.17',
        libraries: 'weather,geometry,visualization'
    });
}]);


// myApp.config(function (socialProvider) {
//     socialProvider.setLinkedInKey("81tqr24ke02ex7");

// });

//  resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),




App.run(["$log", function ($log) {

    $log.log('I\'m a line from custom.js');

}]);

App.constant("MY_CONSTANT", {
    "url": ENV_URL
});
App.constant("MY_CONSTANT1", {
    "url": "http://maps.googleapis.com/maps/api/geocode/json"
});
App.constant("responseCode", {
    "SUCCESS": 200
});

// App.config(['GooglePlusProvider', function (GooglePlusProvider) {
//     GooglePlusProvider.init({
//         clientId: '182626862771-uvcjednv2r3rlus22j10m73d145koe6c.apps.googleusercontent.com',
//         apiKey: 'AIzaSyDfDT92SRyqccY5FOsGfWkM_cIolLyLZaQ'
//     });
// }]);


App.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', 'RouteHelpersProvider', '$facebookProvider', 'socialProvider', 'GooglePlusProvider',
    function ($stateProvider, $locationProvider, $urlRouterProvider, helper, $facebookProvider, socialProvider, GooglePlusProvider) {
        'use strict';
        //$facebookProvider.setAppId('1498414323561854');
        $facebookProvider.setAppId('471967426474652');  //client credentials
        socialProvider.setLinkedInKey("81vxkqrz5nf4n9");
        // GooglePlusProvider.init({
        //     clientId: '182626862771-uvcjednv2r3rlus22j10m73d145koe6c.apps.googleusercontent.com',
        //     apiKey: 'AIzaSyDfDT92SRyqccY5FOsGfWkM_cIolLyLZaQ'
        // });
          GooglePlusProvider.init({
            clientId: '844275640772-tpm3c7rk63qspa4m80g89griuljfpcku.apps.googleusercontent.com',
            apiKey: 'AIzaSyDgzBrYMGjDy33_ZENVdnUy4J2xxBhx-8Q'
        }); //client credentials



        //  Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');  
        //  window.Stripe.setPublishableKey('pk_test_daXLgzZRKVF8igXCuFkQIOPG');
        // $linkedInProvider.set('appKey', '81vxkqrz5nf4n9');
        // Set the following to true to enable the HTML5 Mode
        // You may have to set <base> tag in index and a routing configuration in your server
        $locationProvider.html5Mode(false);

        // default route
        $urlRouterProvider.otherwise('/page/mainLanding');

        // Page Routes
        $stateProvider
            .state('page', {
                url: '/page',
                templateUrl: 'app/components/page/page.html',
                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons'),
                controller: 'pageController'
            })
             .state('page.resetPassword', {
                url: '/resetPassword',
                title: "Reset Password",
                templateUrl: 'app/components/page/ResetPassword/ResetPassword.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'ResetPwdController'
            })
        
        
       
        
        .state('page.support', {
                url: '/support',
                title: "Support",
                templateUrl: 'app/components/page/support/support.html',
                controller: 'WebStructureController'
            })

//          .state('page.contact', {
//                url: '/contact',
//                title: "Contact Us",
//                templateUrl: 'app/components/page/support/contact.html',
//                controller: 'WebStructureController'
//            })
//        
        
        
        
                .state('page.legal', {
                url: '/legal/:pagename',
                title: "Legal",
                templateUrl: 'app/components/page/support/legal.html',
                controller: 'legalController'
            })
        
        
        
        
//         .state('page.policy', {
//                url: '/policy',
//                title: "Policy",
//                templateUrl: 'app/components/page/support/policy.html',
//                controller: 'WebStructureController'
//            })
//
//          .state('page.termsofuse', {
//                url: '/termsofuse',
//                title: "terms Of Use",
//                templateUrl: 'app/components/page/support/termsofuse.html',
//                controller: 'WebStructureController'
//            })
//        
        
        
        
        
        
        
            .state('page.mainLanding', {
                url: '/mainLanding',
                title: "Main Landing",
                templateUrl: 'app/components/page/MainLanding/mainLanding.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'PageMainLandingController as vm'
            })
            .state('page.search', {
                url: '/search?/:city/:looking/:lat/:long',
                title: "Search",
                templateUrl: 'app/components/page/Search/search.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'PageSearchController'
            })
            .state('page.searchDetails', {
                url: '/searchDetails/:id',
                title: "Search Details",
                templateUrl: 'app/components/page/SearchDetails/searchDetails.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'searchDetailsPage'
            })


            //App routes
            .state('app', {
                url: '/app',
                // templateUrl: helper.basepath('app.html'),
                templateUrl: 'app/components/app/app.html',
                controller: 'AppController',
                // resolve: helper.resolveFor('modernizr', 'icons', 'screenfull', 'ngDialog')
            })
            .state('app.search', {
                url: '/search?/:city/:looking/:lat/:long',
                title: "Search",
                templateUrl: 'app/components/app/customer/Search/search.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'searchAfrerLoginController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
             .state('app.ManagePayment', {
                url: '/Cards',
                title: "Manage Cards",
                templateUrl: 'app/components/app/customer/ManagePayment/ManagePayment.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'ManagePaymentController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
            .state('app.searchDetails', {
                url: '/searchDetails/:id',
                title: "Search Details",
                templateUrl: 'app/components/app/customer/SearchDetails/searchDetails.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'searchDetails',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
            .state('app.customerDash', {
                url: '/CustomerDashBoard',
                title: "Customer",
                // templateUrl: helper.basepath('customerDashboard.html'),
                templateUrl: 'app/components/app/customer/CustomerDashboard/customerDashboard.html',
                controller: 'customerDashboard-ctrl',

                //resolve: helper.resolveFor('modernizr', 'icons', 'screenfull', 'ngDialog')
                resolve : {stateRestrict:function($q,$cookieStore){

                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log("roleee",role);
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
            .state('app.CustomerUpdate', {
                url: '/CustomerUpdate',
                title: "Update Customer",
                // templateUrl: helper.basepath('CustomerUpdateProfile.html'),
                templateUrl: 'app/components/app/customer/CustomerUpdate/CustomerUpdateProfile.html',
                controller: 'customerupdate-ctrl',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
                // resolve: helper.resolveFor('modernizr', 'icons', 'screenfull', 'ngDialog')
            })
            .state('app.postjob', {
                url: '/PostJob/:videographerId/:projectId',
                title: "Post Job",
                templateUrl: 'app/components/app/customer/PostJob/PostJob.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'PostJobController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
        
        
        
        
        
                .state('app.hireprojectmanager', {
                url: '/HireProjectManager',
                title: "Hire Project Manager",
                templateUrl: 'app/components/app/customer/HireProjectManager/hireProjectManager.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'HireProjectManager',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
        
        
        
        
        
        
        
        
        

            // .state('app.NewRequest', {
            //     url: '/NewRequest',
            //     title: "Request",
            //     templateUrl: 'app/views/NewRequest.html',
            //     resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
            //     controller: 'NewRequestController'
            // })
            .state('app.AddReview', {
                url: '/AddReview?/:id',
                title: "Review",
                templateUrl: 'app/components/app/customer/AddReview/AddReview.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'AddReviewController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
            // .state('app.customerviewquote', {
            //     url: '/customerViewQuote',
            //     title: "View Quote",
            //     templateUrl: 'app/views/customerViewQuote.html',
            //     resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
            // })

             .state('app.Payment', {
                url: '/Payments/:selectProjectId/:videographerId/:totalamount/:pay',
                title: "Payment",
                templateUrl: 'app/components/app/customer/Payment/Payment.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'PaymentController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
               .state('app.Threads', {
                url: '/Threads',
                title: "Thread",
                templateUrl: 'app/components/app/customer/MyProjectThreads/MyProjectThreads.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'MyProjectThreadsController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })

            .state('app.project', {
                url: '/project',
                title: "project",
                templateUrl: 'app/shared/component/Project/project.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'projectController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer" || role=="videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })

            .state('app.AcceptOffer', {
              url: '/AcceptOffer/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime',
              title: "Accept Offer",
              templateUrl: 'app/components/app/customer/AcceptOffer/AcceptOffer.html',
            //   resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'AcceptOfferController',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })

        
        
        
        
        
        
.state('app.AcceptVideo', {
 url:'/AcceptVideo/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:VideographerDetails/:updatedAt',
              title: "Accept Video",
              templateUrl: 'app/components/app/customer/AcceptVideo/AcceptVideo.html',
            //   resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'AcceptVideoController',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
        
        
        
        
        
        
        
        
        
        
        
        
    .state('app.CompletedProject', {
 url:'/CompletedProject/:id/:VideographerDetails',
              title: "Complete Project",
              templateUrl: 'app/components/app/customer/CompletedProject/CompletedProject.html',
              controller: 'CompletedProject',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })    
        
        
     .state('app.Completed', {
      url: '/Completed/:id/:customer_id',
            title: "Complete Project",
              templateUrl: 'app/components/app/videographer/Completed/Completed.html',
              controller: 'CompletedController',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })

            .state('app.underprocess', {
                url: '/Underprocess',
                title: "Under Process",
                templateUrl: 'app/components/app/videographer/Underprocess/underprocess.html',
                controller: 'underProcessController',
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "videographer"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })








            .state('app.VideoUpload', {
      url: '/VideoUpload/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:customer_id/:updatedAt',
            title: "Video Upload",
              templateUrl: 'app/components/app/videographer/VideoUpload/VideoUpload.html',
            //   resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'VideoUploadController',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
        
        
        
        
        
        
         .state('app.calendar', {
      url: '/calendar',
            title: "calendar",
              templateUrl: 'app/components/app/videographer/calendar/calendar.html',
            //   resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'CalendarCtrl',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })
        
        
        
        
        
        
//         .state('app.VideoUpload', {
//url: '/VideoUpload/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:customer_id/:updatedAt',
//                title: "Video Upload",
//                templateUrl: 'app/views/VideoUpload.html',
//                resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley','moment'),
//                controller: 'VideoUploadController'
//              
//            })
//        
        
        
        
        
        
        
        
        
        
            .state('app.VideoThread', {
                url: '/VideoThread/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:VideographerDetails/:updatedAt',
                title: "Video Thread",
                templateUrl: 'app/shared/component/VideoThread/VideoThread.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),

                controller: 'VideoThreadController',
                resolve: {
                    stateRestrict: function ($q, $cookieStore) {
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole', role);
                        if (role == "customer" || role == "videographer") {
                            defer.resolve();
                        } else {
                            defer.reject();
                        }
                        return defer.promise;
                    }
                }
            })
        
        
        

            .state('app.Chat', {
                url: '/Chat?/:id',
                title: "Chat",
                templateUrl: 'app/shared/component/Chat/chatView.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),

                controller: 'chatViewController',
                resolve: {
                    stateRestrict: function ($q, $cookieStore) {
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole', role);
                        if (role == "customer" || role == "videographer") {
                            defer.resolve();
                        } else {
                            defer.reject();
                        }
                        return defer.promise;
                    }
                }
            })



            .state('app.AcceptQuote', {
              url: '/AcceptQuote/:selectProjectId/:videographerId/:mainVideographerId/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime',
              title: "Accept Quote",
              templateUrl: 'app/components/app/customer/AcceptQuote/AcceptQuote.html',
            //   resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
              controller: 'AcceptQuoteController',
              resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })

        .state('app.ProjectFiles', {
                url: '/ProjectFiles/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:VideographerDetails',
                title: "ProjectFiles",
                templateUrl: 'app/components/app/customer/ProjectFiles/ProjectFiles.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),

                controller: 'ProjectFilesController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "customer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })  


        //VideoGrapher States
         .state('app.videographerDashboard', {
            url: '/Videographer-Landing',
            title: "Videographer Dashboard",
            templateUrl:'app/components/app/videographer/VideographerDashboard/videographerDashboard.html',
         //   resolve: helper.resolveFor('modernizr', 'icons', 'screenfull','ngDialog'),
            controller: 'videographerDashboard-ctrl',
            resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
        })

         .state('app.upload', {
            url: '/upload',
            title: "upload",
            templateUrl: 'app/components/app/videographer/Upload/upload.html',
            // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
            controller:'videographerDetailUpload',
            resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
        })

        .state('app.quotes', {
            url: '/Quotes',
            title: "Quotes",
            templateUrl: 'app/components/app/videographer/Quotes/Quotes.html',
            // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog','parsley'),
            controller:'quotesController',
            resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
        })

        .state('app.submitQuote', {
            url: '/submitQuote/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:projectId',
            title: "submitQuote",
            templateUrl: 'app/components/app/videographer/SubmitQuote/submitQuote.html',
            // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog','parsley'),

            controller:'submitQuoteController',
            resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
        })   





        .state('app.EditQuotes', {
            url: '/EditQuotes/:id/:date/:title/:description/:role/:budgetCost/:duration/:ShotOn/:projectTime/:projectId/:bidPrice',
                title: "EditQuotes",
                templateUrl: 'app/components/app/videographer/EditQuote/EditQuote.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons', 'screenfull'),
                controller: 'EditQuotesController',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })

        .state('app.videographerUpdate', {
                url: '/videographerUpdate',
                title: "update profile",
                templateUrl: 'app/components/app/videographer/VideographerUpdateProfile/UpdateProfile.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog','parsley'),

                controller:'videographerUpdate',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })      


        
        
        
         .state('app.managedAccount', {
                url: '/managedAccount',
                title: "Managed Account",
                templateUrl: 'app/components/app/videographer/managedAccount/managedAccount.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog','parsley'),

                controller:'managedAccount',
                resolve : {stateRestrict:function($q,$cookieStore){
                        var defer = $q.defer();
                        var role = $cookieStore.get('ACL');
                        //console.log('rolerolerolerole',role);
                        if(role == "videographer"){
                            defer.resolve();
                        }else{
                            defer.reject();
                        }
                        return defer.promise;
                }}
            })      

        
        
        


        /*-------------------------------      ADMIN ROUTES  -----------------------------     */
            .state('pageadmin', {
                url: '/pageadmin',
                templateUrl: 'app/components/pageAdmin/pageadmin.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley', 'modernizr', 'icons'),
                controller: 'pageAdminController'
            })
            .state('pageadmin.adminlogin', {
                url: '/admin',
                title: "Admin Login",
                templateUrl: 'app/components/pageAdmin/AdminLogin/login.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'adminLoginController'
            })
          /*  .state('pageadmin.adminpassreset', {
                url: '/adminReset',
                title: "Admin Reset",
                templateUrl: 'app/components/pageAdmin/ResetPasswordAdmin/ResetPassword.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'ResetPwdAdminController'
            })
*/
            .state('app.admindashboard', {
                url: '/admindashboard',
                title: "Admin Dashboard",
                templateUrl: 'app/components/app/admin/AdminDashboard/admindashboard.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins', 'ngDialog', 'parsley'),
                controller: 'adminDashboardController',
                resolve : {stateRestrict:function($q,$cookieStore,RoleAccessService){
                    var defer = $q.defer();
                   /* var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);*/
                    if(RoleAccessService.status == 'admin'){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.customer', {
                url: '/customer',
                title: 'Customer List',
                templateUrl: 'app/components/app/admin/Customer/customer.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog','parsley'),
                controller:'customerController',
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.pm', {
                url: '/project-manager',
                title: 'Project Manager List',
                templateUrl: 'app/components/app/admin/ProjectManager/project-manager.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog','parsley'),
                controller:'pmController',
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.videographer', {
                url: '/videographer',
                title: 'Videographer List',
                templateUrl: 'app/components/app/admin/Videographer/videographer.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"videographerController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.commision', {
                url: '/commision',
                title: 'Commision',
                templateUrl: 'app/components/app/admin/Commission/commision.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"commisionController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.cmsApp', {
                url: '/cms',
                title: 'CMS',
                templateUrl: 'app/components/app/admin/Cms/content/cmsApp.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"cmsAppController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.cmsFaq', {
                url: '/Faq',
                title: 'FAQ',
                templateUrl: 'app/components/app/admin/Cms/faq/faq.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"cmsFaqController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.cmsTerms', {
                url: '/terms',
                title: 'Terms',
                templateUrl: 'app/components/app/admin/Cms/policy/cmsPolicy.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"cmsPolicyController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.cmsPolicy', {
                url: '/policy',
                title: 'Policy',
                templateUrl: 'app/components/app/admin/Cms/policy2/policy2.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"cmsPolicy2Controller",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.category', {
                url: '/category',
                title: 'Category',
                templateUrl: 'app/components/app/admin/Category/categoryList.html',
                //resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"categoryController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.suggestion', {
                url: '/suggestion',
                title: 'Suggestion',
                templateUrl: 'app/components/app/admin/Suggestion/suggestion.html',
                //resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"suggestionController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.allproject', {
                url: '/allprojects',
                title: 'All projects',
                templateUrl: 'app/components/app/admin/Projects/AllProject/allProject.html',
                //resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"allProjectController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.inprogress', {
                url: '/inprogress',
                title: 'Inprogress',
                templateUrl: 'app/components/app/admin/Projects/InprogressProject/inprogressProject.html',
                //resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"inprogressProjectController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.pending', {
                url: '/pending',
                title: 'Pending',
                templateUrl: 'app/components/app/admin/Projects/PendingProject/pendingProject.html',
                //resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"pendingProjectController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.completed', {
                url: '/completed',
                title: 'Completed',
                templateUrl: 'app/components/app/admin/Projects/CompletedProject/completedProject.html',
                //resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"completedProjectController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "admin"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })

        /////////////////////////   PM FLOW /////////////////////////////////

            .state('app.mylist', {
                url: '/mylist',
                title: 'MyList',
                templateUrl: 'app/components/app/pm/Mylist/myList.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"myListController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.acceptedProject', {
                url: '/acceptedProject',
                title: 'Accepted-Project',
                templateUrl: 'app/components/app/pm/AcceptedProject/acceptedProject.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"acceptedProjectController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.progress', {
                url: '/progress',
                title: 'Progress',
                templateUrl: 'app/components/app/pm/Inprogress/inprogress.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"progresspmController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.allpmproject', {
                url: '/allpmprojects',
                title: 'All-Project',
                templateUrl: 'app/components/app/pm/AllProject/allProject.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"allpmProjectController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.pmcompleted', {
                url: '/completed2',
                title: 'Completed',
                templateUrl: 'app/components/app/pm/CompletedProject/completed.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"completedController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.chatPm', {
                url: '/chatPm/:id',
                title: 'Chat-ProjectManager',
                templateUrl: 'app/components/app/pm/Chat/chatPm.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"chatPmController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.offerList', {
                url: '/offerList/:pid',
                title: 'Offer-List',
                templateUrl: 'app/components/app/pm/Offer/offer.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"offerController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
            .state('app.thread', {
                url: '/thread?/:projectId/:currentReceiverId',
                title: 'Thread',
                templateUrl: 'app/components/app/pm/Thread/thread.html',
                // resolve: helper.resolveFor('datatables', 'datatables-pugins','ngDialog'),
                controller:"threadPmController",
                resolve : {stateRestrict:function($q,$cookieStore){
                    var defer = $q.defer();
                    var role = $cookieStore.get('ACL');
                    //console.log('rolerolerolerole',role);
                    if(role == "pm"){
                        defer.resolve();
                    }else{
                        defer.reject();
                    }
                    return defer.promise;
                }}
            })
        


    }]);

App.run(['$rootScope', function ($rootScope) {
    // Load the facebook SDK asynchronously
    (function () {
        // If we've already installed the SDK, we're done
        if (document.getElementById('facebook-jssdk')) { return; }

        // Get the first script element, which we'll use to find the parent node
        var firstScriptElement = document.getElementsByTagName('script')[0];

        // Create a new script element and set its id
        var facebookJS = document.createElement('script');
        facebookJS.id = 'facebook-jssdk';

        // Set the new script's source to the source of the Facebook JS SDK
        facebookJS.src = '//connect.facebook.net/en_US/all.js';

        // Insert the Facebook JS SDK into the DOM
        firstScriptElement.parentNode.insertBefore(facebookJS, firstScriptElement);
    }());
}]);

App.factory('convertdatetime', function () {
    return {

        convertDate: function (DateTime) {
            var _utc = new Date(DateTime);
            var mnth_var_date = parseInt(_utc.getMonth()) + 1;
            var mnth_var = mnth_var_date.toString();
            if (mnth_var.length == 1) {
                var month = "0" + mnth_var;
            } else {
                month = mnth_var;
            }
            if (_utc.getDate().toString().length == 1) {
                var day = "0" + (parseInt(_utc.getDate()));
            } else {
                day = parseInt(_utc.getDate());
            }
            var _utc = _utc.getFullYear() + "-" + month + "-" + day;
            return _utc;
        },

        convertToLocal: function (data) {
            var date = ConvertUTCTimeToLocalTime(data);
            var date_time = new Date((date + 'UTC').replace(/-/g, "/"));
            var date_converted = date_time.toString().replace(/GMT.*/g, "");
            return date_converted;

            function ConvertUTCTimeToLocalTime(UTCDateString) {
                var convertdLocalTime = new Date(UTCDateString);

                var hourOffset = convertdLocalTime.getTimezoneOffset() / 60;

                convertdLocalTime.setHours(convertdLocalTime.getHours() + hourOffset);

                return convertdLocalTime;
            }
        }

    };
});



App.directive('clock', ['dateFilter', '$timeout', function (dateFilter, $timeout) {
    return {
        restrict: 'E',
        scope: {
            format: '@'
        },
        link: function (scope, element, attrs) {
            var updateTime = function () {
                var now = Date.now();

                element.html(dateFilter(now, scope.format));
                $timeout(updateTime, now % 1000);
            };

            updateTime();
        }
    };
}]);


App.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});


App.directive('googleplace', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, model) {
            var options = {
                types: [],
                // componentRestrictions: {}
            };
            scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

            google.maps.event.addListener(scope.gPlace, 'place_changed', function () {
                scope.$apply(function () {
                    model.$setViewValue(element.val());
                });
            });
        }
    };
});