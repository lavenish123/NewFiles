/**
 * Created by admin-in on 27/4/17.
 */

App.controller('searchDetailsPage', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog,ApiService) {
    "use strict";
    $scope.videographerId = $stateParams.id;
    $scope.uniqueid = $stateParams.uniqueid;
    $scope.city = $stateParams.city;
    $scope.latitude = $stateParams.latitude;
    $scope.longitude = $stateParams.longitude
    $('#myTab').tabCollapse();



//////////////////////=============================LOGIN ALERT=============================//////////////////////   
    $scope.loginAlert = function () {
        // $scope.videographerId = data.id;
        ngDialog.open({
            template: 'login-alert',
            className: 'ngdialog-theme-default commandialog',
            showClose: true,
            closeByDocument: false,
            closeByEscape: false,
            scope: $scope
        });
    }

 //////////////////////=============================LOGIN FUNCTION=============================//////////////////////
    $scope.searchlogin = function (data) {
        var fd = new FormData();
        fd.append('email', data.email);
        fd.append('password', data.password);
        fd.append('deviceType', 'WEB');
        fd.append('role', 'customer');
        $scope.loading = true;
        // $http({
        //     url: MY_CONSTANT.url + '/user/login',
        //     method: 'POST',
        //     headers: {
        //         'Content-type': undefined
        //     },
        //     data: fd,
        //     transformRequest: angular.identity   
        // })
        ApiService.apiCall('/user/login','POST',1,fd)
        .success(function (response) {
            $scope.loading = false;
            if (response.statusCode == 200) {
                var obj = { 'accessToken': response.data.token };
                $cookieStore.put('obj', obj);
                var profileDetails = { 'name': response.data.user.name, 'email': response.data.user.email, 'profilePictureURL': response.data.user.profilePictureURL };
                $cookieStore.put("profileDetails", profileDetails);
                ngDialog.close();
                $state.go("app.searchDetails", { "id": $scope.videographerId });
            }
        })
            .error(function (response) {
                $scope.loading = false;
               if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } else {
                    $scope.message = response.message;
                    ngDialog.open({
                        template: 'error'
                        , className: 'ngdialog-theme-default commandialog'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                }
            })
    }





    ///////////////////////////=======================================Details VIDEOGRAPHER=======================////////////////////////////

    $scope.getVideographerDetails = function () {
        // $http({
        //     method: 'GET',
        //     url: MY_CONSTANT.url + '/user/getVideographerDetails?videographerId=' + $scope.videographerId,
        //     headers: { 'Content-type': undefined,
        //      authorization: 'bearer ' + $cookieStore.get('obj').accessToken}
        // })
         ApiService.apiCall('/user/getVideographerDetails?videographerId=' + $scope.videographerId,'GET',0)
            .success(function (response) {
                $scope.data = response.data;
                //console.log("get video details",$scope.data);
            })
            .error(function (response) {
                $scope.message = response.message;
                 if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } 
            })
    }
    $scope.getVideographerDetails();


//////////////////////=============================Quote POPUP=============================//////////////////////
    $scope.quotePopupFun = function () {
        $scope.existProject={};
        //console.log("quote popupppp");
        // $http({
        //     url: MY_CONSTANT.url + '/project/getUnassignedProjects',
        //     method: 'GET',
        //     headers: {
        //         'Content-type': undefined,
        //         authorization: 'bearer ' + $cookieStore.get('obj').accessToken
        //     }
        // })
        ApiService.apiCall('/project/getUnassignedProjects','GET',2)
        .success(function (response) {      
            $scope.list1 = response.data.projects;
              ngDialog.open({
                template: 'quote-Popup',
                className: 'ngdialog-theme-default commandialog getquote',
                showClose: true,
                closeByDocument: false,
                closeByEscape: false,
                scope: $scope
            });
        }).error(function (response) {
             if (response.statusCode == 401) {
                    $cookieStore.remove('obj');
                    $state.go('page.mainLanding');
                } 
            // else{
            //     ngDialog.open({
            //     template: 'quote-Popup',
            //     className: 'ngdialog-theme-default commandialog getquote',
            //     showClose: true,
            //     closeByDocument: false,
            //     closeByEscape: false,
            //     scope: $scope
            // });
        })    
}

    $scope.postJobFun = function(valid){
        if(valid){
            if($scope.existProject.mode=="MANUALLY"){
                $state.go("app.postjob",{'videographerId':$scope.videographerId,'projectId':$scope.existProject.project});
            }else{
                $state.go("app.postjob",{'videographerId':$scope.videographerId});
            }
        }
    }

    //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }

})