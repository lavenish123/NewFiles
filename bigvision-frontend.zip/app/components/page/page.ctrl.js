App.controller('pageController', function ($rootScope, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, $location, $facebook, GooglePlus,ApiService) {
    "use strict";
    
    if ($cookieStore.get('obj') && $cookieStore.get('obj').accessToken != '' && $cookieStore.get('obj').accessToken != "undefined") {
        $state.go('app.customerDash');
    }
});

