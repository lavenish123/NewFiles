/**
 * Created by admin-in on 6/7/17.
 */

App.controller('cmsFaqController', function ($scope,$state,ngDialog, $http,ApiService, $cookies, $cookieStore, MY_CONSTANT, $timeout) {

    'use strict';

    $scope.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    $scope.phnRegex = /[^0][0-9]{9,}$/;
    $scope.alphaRegex = "/^[a-zA-Z\s]*$/";
    /*/^[a-zA-Z ]{2,30}$/;*/
    $scope.loading = false;
    $scope.cmsRole = 0;
    $scope.page = 'landingpage';
    $scope.sno = 0;
    $scope.tableCustomer = false;
    $scope.tableVideographer = false;
    $('#successMsg').hide();
    $('#errorMsg').hide();

    $scope.message = '';


    ApiService.apiCall('/FAQs/getFAQs', 'GET', 0)
        .success(function (data) {
            $scope.loading = false;
            if (data.statusCode == 200) {

                $scope.faq2 = data.data;

            }
        })
        .error(function (response) {
            $('#errorMsg').slideDown('slow');
            $scope.errorMsgR = 'Something Went Wrong';
            $timeout(function () {
                $('#successMsg').slideUp('slow');
                $scope.successMsg = '';
                ngDialog.close();
                $state.reload();
            }, 3000);
        })




    $scope.addfaq = function (data1){
        var fd = new FormData();
        fd.append('question',data1.question);
        ApiService.apiCall('/FAQs/addQuestion', 'POST', 3,fd)
            .success(function (data) {
                $scope.loading = false;
                if (data.statusCode == 200) {

                    var fdd = new FormData();
                    fdd.append('FAQsId',data.data._id);
                    fdd.append('answer',data1.answer);

                    ApiService.apiCall('/FAQs/addAnswer', 'POST', 3,fdd)
                        .success(function (data) {
                            $scope.loading = false;
                            if (data.statusCode == 200) {

                                $('#successMsg').slideDown('slow');
                                $scope.successMsgR = 'FAQ added Successfully';
                                $timeout(function () {
                                    $('#successMsg').slideUp('slow');
                                    $scope.successMsg = '';
                                    ngDialog.close();
                                    $state.reload();
                                }, 2000);

                            }
                        })
                        .error(function (response) {
                            $('#errorMsg').slideDown('slow');
                            $scope.errorMsgR = 'Something Went Wrong';
                            $timeout(function () {
                                $('#successMsg').slideUp('slow');
                                $scope.successMsg = '';
                                ngDialog.close();
                                $state.reload();
                            }, 2000);
                        })

                }
            })
            .error(function (response) {
                $('#errorMsg').slideDown('slow');
                $scope.errorMsgR = 'Something Went Wrong';
                $timeout(function () {
                    $('#successMsg').slideUp('slow');
                    $scope.successMsg = '';
                    ngDialog.close();
                    $state.reload();
                }, 2000);
            })
    }


    $scope.deleteFaq = function (id){
        var fd = new FormData();
        fd.append('FAQsId',id);
        ApiService.apiCall('/FAQs/deleteFAQs', 'PUT', 3,fd)
            .success(function (data) {
                $scope.loading = false;
                if (data.statusCode == 200) {

                    ngDialog.open({
                        template: 'success1'
                        , className: 'dialog-container'
                        , showClose: true
                        , closeByDocument: false
                        , closeByEscape: false
                        , scope: $scope
                    });
                    setTimeout(function(){
                        $scope.close2();
                    },2000);

                }
            })
            .error(function (response) {
                ngDialog.open({
                    template: 'error1'
                    , className: 'dialog-container'
                    , showClose: true
                    , closeByDocument: false
                    , closeByEscape: false
                    , scope: $scope
                });
                setTimeout(function(){
                    $scope.close2();
                },2000);
            })
    }


    $scope.editFaq = function (fdata){
        var fd = new FormData();
        fd.append('FAQsId',$scope.faqdata);
        fd.append('question',fdata.question);
        fd.append('answer',fdata.answer);

        ApiService.apiCall('/FAQs/editFAQs', 'PUT', 3,fd)
            .success(function (data) {
                $scope.loading = false;
                if (data.statusCode == 200) {

                    $('#successMsg').slideDown('slow');
                    $scope.successMsgR = 'FAQ edited Successfully';
                    $timeout(function () {
                        $('#successMsg').slideUp('slow');
                        $scope.successMsg = '';
                        ngDialog.close();
                        $state.reload();
                    }, 2000);

                }
            })
            .error(function (response) {
                $('#errorMsg').slideDown('slow');
                $scope.errorMsgR = 'Something Went Wrong';
                $timeout(function () {
                    $('#successMsg').slideUp('slow');
                    $scope.successMsg = '';
                    ngDialog.close();
                    $state.reload();
                }, 2000);
            })

    }

    $scope.faqpopup = function (){

                $scope.faq = {'question':'','answer':''};
                    ngDialog.open({
                        template: 'addfaq'
                        , className: 'dialog-container big-dialog'
                        , showClose: true
                        , closeByDocument: true
                        , closeByEscape: true
                        , scope: $scope
                    });

    }


    $scope.editpopup = function (de){


        $scope.faqdata = de._id;
        $scope.faq = de;

        ngDialog.open({
            template: 'editfaq'
            , className: 'dialog-container big-dialog'
            , showClose: true
            , closeByDocument: true
            , closeByEscape: true
            , scope: $scope
        });

    }

    $scope.contentChange = function(a,b)
    {
        $scope.content = b;
        $scope.param = a;
        ngDialog.openConfirm({
            template: 'addVideographer',
            className: 'ngdialog-message'
            , showClose: true
            , closeByDocument: false
            , closeByEscape: false,
            scope: $scope
        })
    }









    $scope.close2 = function(){

        $state.reload();

        ngDialog.close();


    }


});
/*
App.directive('ckEditor', function () {
    return {
        require: '?ngModel',
        link: function (scope, elm, attr, ngModel) {
            var ck = CKEDITOR.replace(elm[0]);
            if (!ngModel) return;
            ck.on('instanceReady', function () {
                ck.setData(ngModel.$viewValue);
            });
            function updateModel() {
                scope.$apply(function () {
                    ngModel.$setViewValue(ck.getData());
                });
            }
            ck.on('change', updateModel);
            ck.on('key', updateModel);
            ck.on('dataReady', updateModel);

            ngModel.$render = function (value) {
                ck.setData(ngModel.$viewValue);
            };
        }
    };
});*/
