/**
 * Created by sanjay on 3/28/15.
 */

App.controller('adminDashboardController', function ($scope, $http, $cookies, $cookieStore,ApiService,ngDialog,$modal, MY_CONSTANT, $state, responseCode) {
    $scope.stats={};
    $scope.stats.rides = 0;
    $scope.stats.users = 0;
    $scope.stats.revenue = 0;
    $scope.loading = false;
    //console.log("inside controller");
    var now = new Date();
    var yesterday = now.setDate(now.getDate() - 1);
    ApiService.apiCall('/admin/Report/dashboard', 'GET', 2)
        .success(function(data) {
            $scope.loading = false;
            if(data.statusCode == 200)
            {
                $scope.result = data.data;
               //console.log('dashboard',data)
            }
        })
        .error(function (response) {
            //console.log('ERROR', response.message);
            ngDialog.close();
            // $scope.message = response.message;
            ngDialog.open({
                template: 'error1'
                , className: 'dialog-container'
                , showClose: true
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
            $scope.message = '';
            // $state.reload();
        })
});
