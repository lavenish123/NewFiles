/**
 * Created by admin-in on 27/4/17.
 */
App.controller('AcceptOfferController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
    $scope.selectProjectId = $stateParams.id;
    $scope.projectId = $stateParams.projectId;
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    //console.log($scope.proTitle);
    
    

    
    
    $scope.page = 10;
    ////////////////////=============================Get  My Quotes=============================//////////////////////
    
    
    $scope.getQuotesVideographerList = function (skip) {
        ApiService.apiCall('/bidding/getQuotesForProject?projectId=' + $scope.selectProjectId + "&skip=" + skip + "&limit=" + 10, 'GET', 2).success(function (response) {
            //console.log(response.data.quotes);
            $scope.QuotesVideographerList = response.data.quotes;
            $scope.count = response.data.count;
        }).error(function (response) {
            //console.log(response);
        });
        ngDialog.closeAll();
    }
    $scope.getQuotesVideographerList(0);
    //console.log("selectProjectId " + $scope.selectProjectId);
    
    
    
    ///=========================================Delete Msg Popup Items=============================///////   
    $scope.deleteMsgPopupItems = function (currentId) {
            $scope.deleteCurrentItemId = currentId;
            $scope.DeleteConfirmMsg = "Are you sure to delete this item?";
            ngDialog.open({
                template: 'deleteitemMsg'
                , className: 'ngdialog-theme-default commandialog'
                , showClose: false
                , closeByDocument: false
                , closeByEscape: false
                , scope: $scope
            });
        }
        ////////////////////=============================Remove Quote ByCustomer=============================//////////////////////
    $scope.removeQuoteByCustome = function () {
        var fd = new FormData();
        fd.append("projectId", $scope.selectProjectId);
        fd.append("videographerId", $scope.deleteCurrentItemId);
        ApiService.apiCall('/bidding/removeQuoteByCustomer', 'PUT', 3, fd).success(function (response) {
            if (response.statusCode == 200) {
                $scope.getQuotesVideographerList();
            }
            //            //console.log(response.data.quotes);
            //            $scope.QuotesVideographerList = response.data.quotes
        }).error(function (response) {
            //console.log(response);
        });
    }
    //console.log($scope.selectProjectId);
    
    
    //////////////////////=============================closeDialog=============================//////////////////////
    $scope.closeDialog = function () {
        ngDialog.closeAll();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
   
$scope.ProjectDetails = [];
$scope.projectInfo = {}
$scope.myQuotes = function () {
    $http({
        method: 'GET'
        , url: MY_CONSTANT.url + '/project/getProjectByCustomer?limit=' + 10 + '&skip=' + 0 + '&projectStatus=[' + 1 + ']'
        , headers: {
            'Content-type': undefined
            , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
        }
    }).success(function (response) {
        //console.log("AcceptOffer AcceptOffer AcceptOffer AcceptOffer", response);
        $scope.loading = false;
        $scope.list = response.data.userData;
        for (i = 0; i < $scope.list.length; i++) {
            if ($scope.list[i]._id == $scope.selectProjectId) {
                $scope.ProjectDetails.push($scope.list[i]);
            }
        }
        //console.log("selectProjectId hhhhh", $scope.selectProjectId);
        //console.log("ProjectDetails hhhhh", $scope.ProjectDetails);
        $scope.projectInfo = {
                "proTitle": $scope.ProjectDetails[0].title
                , "proDescription": $scope.ProjectDetails[0].description
                , "createDate": $scope.ProjectDetails[0].createdAt
                , "duration": $scope.ProjectDetails[0].projectDuration
                , "ShotOn": $scope.ProjectDetails[0].projectDate
                , "budgetCost": $scope.ProjectDetails[0].budgetCost
                , "createdBy": $scope.ProjectDetails[0].createdBy
                , "updatedAt": $scope.ProjectDetails[0].updatedAt
            , }
            //              $scope.transferredCost = $scope.projectInfo.budgetCost / 2;
            //               $scope.updatedAt =  $scope.projectInfo.updatedAt;
        $scope.projTime = $scope.ProjectDetails[0].projectTime
        $scope.timeAm = "AM";
        if ($scope.projTime >= 12) {
            $scope.projTime = parseInt($scope.projTime) - 12;
            $scope.timeAm = "PM";
        }
        else {
            //console.log("small" + $scope.projTime);
        }
        //console.log("projectInfoprojectInfoprojectInfoprojectInfo", $scope.ProjectDetails[0].projectTime);
    }).error(function (response) {})
}
$scope.myQuotes();
    
    
    
    
    
    
    
    
    
    
})