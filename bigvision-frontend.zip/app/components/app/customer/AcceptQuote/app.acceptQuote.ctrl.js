/**
 * Created by admin-in on 27/4/17.
 */
App.controller('AcceptQuoteController', function ($rootScope, $stateParams, $scope, $http, $cookies, $cookieStore, MY_CONSTANT, $state, $modal, $timeout, ngDialog, ApiService) {
    //console.log("AcceptQuoteController");
    $scope.quotetxt = {};
    $scope.currentVideographerlist = [];
    $scope.selectProjectId = $stateParams.selectProjectId;
    $scope.selectvideographerId = $stateParams.videographerId;
    $scope.mainVideographerId = $stateParams.mainVideographerId;
    //console.log("main vd id", $scope.mainVideographerId);
    $scope.createDate = $stateParams.date;
    $scope.proTitle = $stateParams.title;
    $scope.proDescription = $stateParams.description;
    $scope.proRole = $stateParams.role;
    $scope.budgetCost = $stateParams.budgetCost;
    $scope.duration = $stateParams.duration;
    $scope.ShotOn = $stateParams.ShotOn;
    $scope.projectTime = $stateParams.projectTime;
    $scope.proPay = 'hpay';
    //console.log($scope.proTitle);
    $scope.timeAm = "AM";
    if ($scope.projectTime >= 12) {
        $scope.projectTime = parseInt($scope.projectTime) - 12;
        $scope.timeAm = "PM";
    }
    else {
        //console.log("small" + $scope.projectTime);
    }
    //     //console.log("selectProjectId "  + $scope.selectProjectId);
    //     //console.log("selectvideographerId " +  $scope.selectvideographerId);
    ////////////////////=============================Get QuotesVideographer Iteam List=============================//////////////////////
    $scope.getQuotesVideographerList = function () {
        ApiService.apiCall('/bidding/getQuotesForProject?projectId=' + $scope.selectProjectId + "&skip=" + 0 + "&limit=" + 10, 'GET', 2).success(function (response) {
            //console.log(response.data.quotes);
            $scope.listlength = response.data.quotes.length;
            //console.log($scope.listlength);
            //console.log(response.data.quotes[0]._id);
            for (i = 0; i < $scope.listlength; i++) {
                if (response.data.quotes[i]._id == $scope.selectvideographerId) {
                    //console.log("Done");
                    $scope.currentVideographerlist.push(response.data.quotes[i]);
                }
                else if (response.data.quotes[i]._id != $scope.selectvideographerId) {
                    //console.log("Not Done");
                }
            }
            $scope.currentVideographerItem = $scope.currentVideographerlist[0].items;
            if ($scope.currentVideographerlist[0].note == 'undefined') {
                $scope.currentVideographerlist[0].note = "";
            }
            $scope.quotetxt.note = $scope.currentVideographerlist[0].note;
            
            $scope.totalamount = 0;
            for (var i = 0; i < $scope.currentVideographerItem.length; i++) {
                $scope.totalamount = $scope.totalamount + $scope.currentVideographerItem[i].amount;
            }
            
            $scope.payAmount = $scope.totalamount/2;
            
            
        }).error(function (response) {
            //console.log(response);
        });
    }
    
    
    
    
///////======myQuotes===///////
    
    
    $scope.getQuotesVideographerList();
    $scope.ProjectDetails = [];
    $scope.projectInfo = {}
    $scope.myQuotes = function () {
        $http({
            method: 'GET'
            , url: MY_CONSTANT.url + '/project/getProjectByCustomer?limit=' + 10 + '&skip=' + 0 + '&projectStatus=[' + 1 + ']'
            , headers: {
                'Content-type': undefined
                , authorization: 'bearer ' + $cookieStore.get('obj').accessToken
            }
        }).success(function (response) {
            //console.log("AcceptOffer AcceptOffer AcceptOffer AcceptOffer", response);
            $scope.loading = false;
            $scope.list = response.data.userData;
            for (i = 0; i < $scope.list.length; i++) {
                if ($scope.list[i]._id == $scope.selectProjectId) {
                    $scope.ProjectDetails.push($scope.list[i]);
                }
            }
            //console.log("selectProjectId hhhhh", $scope.selectProjectId);
            //console.log("ProjectDetails hhhhh", $scope.ProjectDetails);
            $scope.projectInfo = {
                    "proTitle": $scope.ProjectDetails[0].title
                    , "proDescription": $scope.ProjectDetails[0].description
                    , "createDate": $scope.ProjectDetails[0].createdAt
                    , "duration": $scope.ProjectDetails[0].projectDuration
                    , "ShotOn": $scope.ProjectDetails[0].projectDate
                    , "budgetCost": $scope.ProjectDetails[0].budgetCost
                    , "createdBy": $scope.ProjectDetails[0].createdBy
                    , "updatedAt": $scope.ProjectDetails[0].updatedAt
                , }
                //              $scope.transferredCost = $scope.projectInfo.budgetCost / 2;
                //               $scope.updatedAt =  $scope.projectInfo.updatedAt;
            $scope.projTime = $scope.ProjectDetails[0].projectTime
            $scope.timeAm = "AM";
            if ($scope.projTime >= 12) {
                $scope.projTime = parseInt($scope.projTime) - 12;
                $scope.timeAm = "PM";
            }
            else {
                //console.log("small" + $scope.projTime);
            }
            //console.log("projectInfoprojectInfoprojectInfoprojectInfo", $scope.ProjectDetails[0].projectTime);
        }).error(function (response) {})
    }
    $scope.myQuotes();
})